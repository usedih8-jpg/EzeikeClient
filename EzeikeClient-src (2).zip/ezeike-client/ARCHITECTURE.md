# Ezeike Client — Architecture Reference

## Package Layout

```
com.ezeike.client
├── EzeikeClient.java              Main @Mod entry point / singleton hub
├── config/
│   └── ConfigManager.java         Flat-file persistence (key=value .cfg)
├── event/
│   └── EventManager.java          Global Forge event listeners (auto-save, etc.)
├── gui/
│   ├── GuiHUDConfig.java          HUD drag-and-drop editor (Right Shift)
│   └── HudTheme.java              Single source of truth for ALL HUD colours & sizing
├── module/
│   ├── Module.java                Base class for every feature
│   ├── ModuleManager.java         Registry; owns all Module instances
│   └── setting/
│       ├── Setting.java           Generic typed setting base
│       ├── BooleanSetting.java    Toggle
│       ├── SliderSetting.java     Numeric range
│       ├── ColorSetting.java      ARGB int
│       └── ModeSetting.java       Enum / string list
├── module/modules/
│   ├── visual/                    Performance & visual modules
│   │   ├── Fullbright.java
│   │   ├── FOVChanger.java
│   │   ├── GlintColorizer.java
│   │   ├── ChunkBorders.java
│   │   ├── HitColor.java
│   │   ├── MotionBlur.java
│   │   └── ParticleChanger.java
│   ├── hud/                       HUD & informational displays (Lunar-style)
│   │   ├── FPSDisplay.java
│   │   ├── PingDisplay.java
│   │   ├── CPSDisplay.java
│   │   ├── KeyStrokes.java
│   │   ├── ArmorStatus.java
│   │   ├── PotionEffects.java
│   │   ├── CrosshairCustomiser.java
│   │   ├── ScoreboardDisplay.java
│   │   ├── ServerAddress.java
│   │   ├── Coordinates.java
│   │   └── DayCounter.java
│   ├── combat/                    PvP & combat utilities
│   │   ├── Zoom.java
│   │   ├── TNTCountdown.java
│   │   ├── NameTags.java
│   │   └── DamageTint.java
│   └── qol/                       Quality of Life
│       ├── FreeLook.java
│       ├── WAILA.java
│       ├── WeatherChanger.java
│       ├── HypixelQuickplay.java
│       └── GuiQuickplay.java
└── util/
    ├── Logger.java                Log4j wrapper
    └── RenderUtil.java            2D GUI drawing helpers
```

---

## HUD Visual Theme — Lunar Client Inspired

All HUD modules read from `HudTheme.java` — the single source of truth.
Changing one constant updates every element instantly.

### HudTheme constants

| Constant          | Value        | Purpose                                        |
|-------------------|--------------|------------------------------------------------|
| `BG`              | `0x70000000` | Card background — 44 % opacity black           |
| `BG_ROW_HOVER`    | `0x22FFFFFF` | Sidebar row hover tint                         |
| `EDGE`            | `0x40FFFFFF` | Barely-visible card edge                       |
| `TEXT`            | `0xFFFFFFFF` | Primary text                                   |
| `TEXT_DIM`        | `0xFFAAAAAA` | Secondary / timer text                         |
| `TEXT_DARK`       | `0xFF888888` | Scores, muted values                           |
| `GOOD`            | `0xFF55FF55` | ≥60 FPS / ≤80 ms ping                          |
| `OK`              | `0xFFFFFF55` | 30–60 FPS / 80–150 ms                          |
| `BAD`             | `0xFFFF5555` | <30 FPS / >150 ms / low health                 |
| `ACCENT`          | `0xFF8A2BE2` | Purple — pressed keys, active elements, titles |
| `ACCENT_ACTIVE`   | `0xFFAA55FF` | Lighter purple hover state                     |
| `KEY_BG`          | `0xBB1A1A1A` | Idle keystroke key fill                        |
| `KEY_BORDER`      | `0xFF444444` | Idle key edge                                  |
| `KEY_ACTIVE_BG`   | `0xFFEEEEEE` | Pressed key fill (near-white, like Lunar)      |
| `KEY_ACTIVE_TXT`  | `0xFF111111` | Dark text on pressed key                       |
| `KEY_IDLE_TXT`    | `0xFF999999` | Mid-grey text on idle key                      |
| `RADIUS`          | `3f`         | Corner radius for all rounded rects            |
| `PADDING`         | `2`          | Inner card padding (px)                        |

### Design rules (match Lunar exactly)

1. **Cards are nearly invisible at a glance.** Background opacity ~44 %; no heavy outlines.
2. **Borders appear only on hover/drag** — `EDGE` is near-transparent at rest.
3. **Colour = information.** FPS/Ping are green/yellow/red. Everything else is white.
4. **KeyStrokes**: idle keys dark + grey text; pressed keys near-white fill + dark text + purple border.
5. **Scoreboard**: title in `ACCENT` purple; scores in `TEXT_DARK` dim grey; no red column.
6. **Potion effects**: coloured dot (`●`) before name; timer right-aligned in a fixed-width card.
7. **Purple is rare** — only on: active keystroke borders, scoreboard title, sidebar dots,
   dragged card border, left accent bar on enabled elements. Nothing else.

---

## Key Architecture Decisions

### Singleton Hub (`EzeikeClient`)
The `@Mod` class is the single dependency root.  All subsystems accessed via
`EzeikeClient.getInstance().get*Manager()`.

### Event Bus Lifecycle
Modules register/unregister themselves on toggle.  Disabled modules have **zero overhead**.

### HUD Element Flag
Modules override `isHudElement() → true` to appear in `GuiHUDConfig`.
Position (`posX`, `posY`) and `scale` live on the base `Module` class.

### Config Format
Standard `Properties` flat file: `.minecraft/config/ezeikeclient/modules.cfg`.
Auto-save every 5 minutes via `EventManager`.

---

## Phase 2 Roadmap

- **Click GUI** (`GuiModuleList`) — category tabs, search, per-module settings panel.
- **Mixin wiring** — GlintColorizer → `RenderItem`, HitColor → `Entity`, ScoreboardDisplay → `GuiIngame`.
- **Remaining modules** — FireHeight, SaturationFilter, ItemPhysics, ShinyPots, ScreenshotUploader, MumbleLink, WorldEditCUI.
- **Custom font** — TTF wrapper for sharper text at small sizes.

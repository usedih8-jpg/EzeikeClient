# How to get EzeikeClient.jar on PojavLauncher (mobile, no PC needed)

## Step 1 — Upload to GitHub (one-time setup, ~3 minutes)

1. Go to **github.com** in your phone browser and sign in (or create a free account)
2. Tap the **+** icon → **New repository**
3. Name it `ezeike-client`, set it to **Public**, tap **Create repository**
4. On the next page tap **uploading an existing file**
5. Unzip `EzeikeClient-src.zip` — upload **all the files and folders** from inside the `ezeike-client/` folder
6. Scroll down → tap **Commit changes**

## Step 2 — Wait for GitHub to build the JAR (~5–10 minutes)

1. In your repo, tap the **Actions** tab at the top
2. You will see a workflow run called **"Build Ezeike Client"** — wait for the green ✓
3. Tap the workflow run → scroll down to **Artifacts**
4. Tap **EzeikeClient-1.0.0** to download the compiled JAR

## Step 3 — Install in PojavLauncher

1. Open **Files** on your phone and find the downloaded `EzeikeClient-1.0.0.zip`
   (GitHub wraps the artifact in a zip — unzip it to get the `.jar` inside)
2. Move `EzeikeClient-1.0.0.jar` to:
   `/storage/emulated/0/games/PojavLauncher/.minecraft/mods/`
   (Create the `mods/` folder if it doesn't exist)

## Step 4 — Set up Forge in PojavLauncher

1. Open PojavLauncher
2. Tap the account icon → select your account
3. Tap **Install** → search for **Forge 1.8.9** → install version `1.8.9-11.15.1.2318`
4. Select the Forge 1.8.9 profile and tap **Play**

The mod loads automatically — you'll see "Ezeike Client" in the Forge mod list on the title screen.

## Controls

| Keybind | Action |
|---|---|
| Right Shift | Open HUD editor (drag elements around) |
| Right Ctrl | Open module list (toggle features) |

## Modules included

**HUD** — FPS, Ping, CPS, KeyStrokes, Armor Status, Potion Effects, Crosshair, Scoreboard, Coordinates, Server Address, Day Counter

**Visual** — Fullbright, FOV Changer, Motion Blur, Particle Changer, Glint Colorizer, Hit Color, Chunk Borders

**Combat** — Zoom, Damage Tint, Name Tags, TNT Countdown

**QOL** — Free Look, WAILA, Weather Changer, Hypixel Quickplay

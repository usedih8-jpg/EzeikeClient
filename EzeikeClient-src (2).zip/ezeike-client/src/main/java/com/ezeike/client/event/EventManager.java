package com.ezeike.client.event;

import com.ezeike.client.config.ConfigManager;
import com.ezeike.client.EzeikeClient;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Handles global game events that belong to no single module.
 *
 * Responsibilities:
 *   - Auto-saving the config on a periodic timer (every 5 minutes).
 *   - Acting as a central event relay if needed in the future.
 */
public class EventManager {

    /** Auto-save every 6000 ticks ≈ 5 minutes at 20 TPS. */
    private static final int AUTO_SAVE_INTERVAL = 6000;

    private int tickCounter = 0;

    public EventManager() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        tickCounter++;
        if (tickCounter >= AUTO_SAVE_INTERVAL) {
            tickCounter = 0;
            ConfigManager cfg = EzeikeClient.getInstance().getConfigManager();
            if (cfg != null) cfg.save();
        }
    }
}

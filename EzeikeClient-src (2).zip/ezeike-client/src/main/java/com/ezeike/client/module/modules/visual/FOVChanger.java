package com.ezeike.client.module.modules.visual;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.SliderSetting;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * FOV Changer — overrides the game's FOV with a user-defined value.
 *
 * The module intercepts Forge's {@link FOVUpdateEvent} and replaces the
 * computed FOV with the slider value, preventing vanilla modifiers (sprint,
 * speed potion, bow pull) from altering the view when locked.
 */
public class FOVChanger extends Module {

    private final SliderSetting fov  = register(new SliderSetting("FOV",  "Field of view in degrees.", 90, 30, 180, 1));
    private final SliderSetting lock = register(new SliderSetting("Lock", "0 = use slider, 1 = ignore vanilla modifiers.", 1, 0, 1, 1));

    public FOVChanger() {
        super("FOV Changer", Category.VISUAL, "Custom field-of-view override.");
    }

    @SubscribeEvent
    public void onFOVUpdate(FOVUpdateEvent event) {
        if (lock.getValue() >= 1.0) {
            event.newfov = (float)(fov.getValue() / 70.0); // Forge multiplier is relative to 70°
        }
    }
}

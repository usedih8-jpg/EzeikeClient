package com.ezeike.client.gui;

import com.ezeike.client.EzeikeClient;
import com.ezeike.client.module.Module;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * HUD Customiser Screen — Summer Night theme.
 *
 * The editor feels like standing on a warm beach at 2am:
 *   • Thin dark-navy overlay over the world (barely dims it).
 *   • Cards float with a soft moonlit silver glow on hover.
 *   • Teal accent appears only on the dragged card border.
 *   • Sidebar uses cool blue-grey tones — no harsh contrast.
 *   • Bottom hint bar is whisper-quiet.
 */
public class GuiHUDConfig extends GuiScreen {

    // ---------------------------------------------------------------  Grid
    private static final int GRID = 8;

    // ---------------------------------------------------------------  Editor colours  (navy night palette)
    private static final int C_OVERLAY      = 0x44091422;   // near-invisible tint
    private static final int C_CARD_IDLE    = 0x880D1B2A;   // deep navy card
    private static final int C_CARD_HOVER   = 0xAA122038;   // slightly lighter on hover
    private static final int C_CARD_DRAG    = 0xCC0D2040;   // dragging — richest navy
    private static final int C_BORDER_IDLE  = 0x25C8D8E8;   // barely-there silver edge
    private static final int C_BORDER_HOVER = 0x60C8D8E8;   // soft moonlight on hover
    private static final int C_BORDER_DRAG  = HudTheme.ACCENT;      // teal on drag
    private static final int C_BADGE_ON     = HudTheme.GOOD;
    private static final int C_BADGE_OFF    = HudTheme.TEXT_DARK;
    private static final int C_SIDEBAR_BG   = 0xCC091422;

    // ---------------------------------------------------------------  Sidebar geometry
    private static final int SIDEBAR_W   = 150;
    private static final int SIDEBAR_PAD = 6;
    private static final int SIDEBAR_ROW = 15;

    // ---------------------------------------------------------------  State
    private List<Module> hudModules;
    private Module       dragging = null;
    private double       dragOffX, dragOffY;
    private int          sw, sh;

    private final Map<Module, Float> hoverFrac = new HashMap<>();

    // ---------------------------------------------------------------  Lifecycle

    @Override
    public void initGui() {
        super.initGui();
        ScaledResolution sr = new ScaledResolution(mc);
        sw = sr.getScaledWidth();
        sh = sr.getScaledHeight();
        hudModules = EzeikeClient.getInstance().getModuleManager().getHudModules();
    }

    @Override
    public void onGuiClosed() {
        EzeikeClient.getInstance().getConfigManager().save();
    }

    // ---------------------------------------------------------------  Render

    @Override
    public void drawScreen(int mx, int my, float pt) {
        // 1. Thin navy overlay — world still visible through it
        RenderUtil.drawRect(0, 0, sw, sh, C_OVERLAY);

        // 2. HUD element cards
        for (Module m : hudModules) drawCard(m, mx, my);

        // 3. Sidebar
        drawSidebar(mx, my);

        // 4. Whisper hint bar at bottom
        String hint = "Drag  ·  Right-click to toggle  ·  Esc to save";
        int hw = mc.fontRendererObj.getStringWidth(hint);
        RenderUtil.drawRect(0, sh - 13, sw, 13, 0x660D1B2A);
        mc.fontRendererObj.drawStringWithShadow(hint,
            (sw - hw) / 2f, sh - 10, HudTheme.TEXT_DARK);

        super.drawScreen(mx, my, pt);
    }

    /** Floating card for one HUD module. */
    private void drawCard(Module m, int mx, int my) {
        int pad = 4;
        int fh  = mc.fontRendererObj.FONT_HEIGHT;
        int lw  = mc.fontRendererObj.getStringWidth(m.getName());
        int cw  = lw + pad * 2 + 20;
        int ch  = fh + pad * 2;

        double cx = m.getPosX(), cy = m.getPosY();
        boolean dragged = dragging == m;
        boolean hovered = !dragged && mx >= cx && mx <= cx + cw && my >= cy && my <= cy + ch;

        float f = hoverFrac.getOrDefault(m, 0f);
        f += ((hovered || dragged ? 1f : 0f) - f) * 0.18f;
        hoverFrac.put(m, f);

        int bg     = dragged ? C_CARD_DRAG : RenderUtil.lerpColor(C_CARD_IDLE, C_CARD_HOVER, f);
        int border = dragged ? C_BORDER_DRAG
                   : RenderUtil.lerpColor(C_BORDER_IDLE, C_BORDER_HOVER, f);

        RenderUtil.drawRoundedRect(cx, cy, cw, ch, HudTheme.RADIUS, bg);
        RenderUtil.drawOutline(cx, cy, cw, ch, dragged ? 1.5f : 1f, border);

        // Left teal accent bar — only when enabled
        if (m.isEnabled()) {
            RenderUtil.drawRect(cx, cy, 2, ch, HudTheme.ACCENT);
        }

        // Name
        mc.fontRendererObj.drawStringWithShadow(m.getName(),
            (float)(cx + pad + 3), (float)(cy + pad),
            m.isEnabled() ? HudTheme.TEXT : HudTheme.TEXT_DARK);

        // Badge
        String badge = m.isEnabled() ? "ON" : "OFF";
        mc.fontRendererObj.drawStringWithShadow(badge,
            (float)(cx + cw - mc.fontRendererObj.getStringWidth(badge) - pad),
            (float)(cy + pad),
            m.isEnabled() ? C_BADGE_ON : C_BADGE_OFF);
    }

    /** Sidebar — moonlight navy panel with dot indicators. */
    private void drawSidebar(int mx, int my) {
        int sbX = sw - SIDEBAR_W - 8;
        int sbY = 24;
        int sbH = SIDEBAR_ROW * hudModules.size() + SIDEBAR_PAD * 2 + 18;

        RenderUtil.drawRoundedRect(sbX, sbY, SIDEBAR_W, sbH, HudTheme.RADIUS, C_SIDEBAR_BG);
        RenderUtil.drawOutline(sbX, sbY, SIDEBAR_W, sbH, 1f, HudTheme.EDGE);

        // Title
        mc.fontRendererObj.drawStringWithShadow("HUD Elements",
            sbX + SIDEBAR_PAD, sbY + SIDEBAR_PAD, HudTheme.ACCENT);

        // Separator
        RenderUtil.drawRect(sbX + 4, sbY + 15, SIDEBAR_W - 8, 1, HudTheme.EDGE);

        for (int i = 0; i < hudModules.size(); i++) {
            Module m = hudModules.get(i);
            int ry   = sbY + 18 + SIDEBAR_PAD + i * SIDEBAR_ROW;

            boolean hov = mx >= sbX && mx <= sbX + SIDEBAR_W && my >= ry && my <= ry + SIDEBAR_ROW;
            if (hov) RenderUtil.drawRect(sbX + 2, ry, SIDEBAR_W - 4, SIDEBAR_ROW - 1, HudTheme.BG_ROW_HOVER);

            // Status dot
            mc.fontRendererObj.drawStringWithShadow("●", sbX + SIDEBAR_PAD, ry + 3,
                m.isEnabled() ? HudTheme.ACCENT : HudTheme.TEXT_DARK);

            // Name
            mc.fontRendererObj.drawStringWithShadow(m.getName(),
                sbX + SIDEBAR_PAD + 10, ry + 3,
                m.isEnabled() ? HudTheme.TEXT : HudTheme.TEXT_DIM);
        }
    }

    // ---------------------------------------------------------------  Mouse

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);

        // Sidebar click → toggle
        int sbX = sw - SIDEBAR_W - 8, sbY = 24;
        for (int i = 0; i < hudModules.size(); i++) {
            int ry = sbY + 18 + SIDEBAR_PAD + i * SIDEBAR_ROW;
            if (mx >= sbX && mx <= sbX + SIDEBAR_W && my >= ry && my <= ry + SIDEBAR_ROW) {
                hudModules.get(i).toggle();
                return;
            }
        }

        // Card click
        for (Module m : hudModules) {
            int pad = 4, fh = mc.fontRendererObj.FONT_HEIGHT;
            int cw = mc.fontRendererObj.getStringWidth(m.getName()) + pad * 2 + 20;
            int ch = fh + pad * 2;
            double cx = m.getPosX(), cy = m.getPosY();

            if (mx >= cx && mx <= cx + cw && my >= cy && my <= cy + ch) {
                if (btn == 0) { dragging = m; dragOffX = mx - cx; dragOffY = my - cy; }
                else if (btn == 1) m.toggle();
                return;
            }
        }
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        if (dragging != null) {
            // Snap to grid on release
            dragging.setPosX(Math.round(dragging.getPosX() / GRID) * GRID);
            dragging.setPosY(Math.round(dragging.getPosY() / GRID) * GRID);
            dragging = null;
        }
    }

    @Override
    public void mouseClickMove(int mx, int my, int clickedBtn, long timeSince) {
        super.mouseClickMove(mx, my, clickedBtn, timeSince);
        if (dragging == null || clickedBtn != 0) return;
        dragging.setPosX(Math.max(0, Math.min(mx - dragOffX, sw - 60)));
        dragging.setPosY(Math.max(22, Math.min(my - dragOffY, sh - 30)));
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}

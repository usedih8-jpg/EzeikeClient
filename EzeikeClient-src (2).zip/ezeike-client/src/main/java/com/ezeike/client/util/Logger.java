package com.ezeike.client.util;

import com.ezeike.client.EzeikeClient;
import org.apache.logging.log4j.LogManager;

/**
 * Thin wrapper around Log4j so the rest of the codebase doesn't import
 * logging directly and we can swap implementations easily.
 */
public final class Logger {

    private static final org.apache.logging.log4j.Logger LOG =
        LogManager.getLogger(EzeikeClient.MOD_NAME);

    private Logger() {}

    public static void info(String msg)             { LOG.info("[Ezeike] " + msg); }
    public static void warn(String msg)             { LOG.warn("[Ezeike] " + msg); }
    public static void error(String msg)            { LOG.error("[Ezeike] " + msg); }
    public static void error(String msg, Throwable t) { LOG.error("[Ezeike] " + msg, t); }
    public static void debug(String msg)            { LOG.debug("[Ezeike] " + msg); }
}

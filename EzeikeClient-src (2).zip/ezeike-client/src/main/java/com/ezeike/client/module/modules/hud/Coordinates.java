package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Coordinates — Lunar-style two-line card:
 *
 *   ┌──────────────────────┐
 *   │ X: 1024  Z: -512     │   ← dim label, white value
 *   │ Y: 64    [North]     │
 *   └──────────────────────┘
 */
public class Coordinates extends Module {

    private final BooleanSetting background = register(new BooleanSetting("Background", true));
    private final BooleanSetting showDir    = register(new BooleanSetting("Direction", true));
    private final BooleanSetting twoLines   = register(new BooleanSetting("Two Lines", true));

    public Coordinates() {
        super("Coordinates", Category.HUD, "Shows player XYZ and facing direction.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.thePlayer == null) return;

        int px = (int) Math.floor(mc.thePlayer.posX);
        int py = (int) Math.floor(mc.thePlayer.posY);
        int pz = (int) Math.floor(mc.thePlayer.posZ);

        String dir = "";
        if (showDir.isEnabled()) {
            float yaw = ((mc.thePlayer.rotationYaw % 360) + 360) % 360;
            if      (yaw < 45 || yaw >= 315) dir = "South";
            else if (yaw < 135)              dir = "West";
            else if (yaw < 225)              dir = "North";
            else                             dir = "East";
        }

        int x = (int) getPosX(), y = (int) getPosY();
        int fh = mc.fontRendererObj.FONT_HEIGHT;
        int p  = HudTheme.PADDING + 2;

        if (twoLines.isEnabled()) {
            // Line 1: X and Z
            String xzLine = "X: " + px + "  Z: " + pz;
            // Line 2: Y and direction
            String yLine  = "Y: " + py + (showDir.isEnabled() ? "  " + dir : "");

            int cardW = Math.max(mc.fontRendererObj.getStringWidth(xzLine),
                                 mc.fontRendererObj.getStringWidth(yLine)) + p * 2 + 2;
            int cardH = fh * 2 + p * 2 + 2;

            if (background.isEnabled()) {
                RenderUtil.drawRoundedRect(x - p, y - p, cardW, cardH, HudTheme.RADIUS, HudTheme.BG);
            }

            mc.fontRendererObj.drawStringWithShadow(xzLine, x + 1, y,          HudTheme.TEXT);
            mc.fontRendererObj.drawStringWithShadow(yLine,  x + 1, y + fh + 1, HudTheme.TEXT_DIM);
        } else {
            // Single-line compact: "1024 / 64 / -512  North"
            String label = px + " / " + py + " / " + pz
                         + (showDir.isEnabled() ? "  " + dir : "");
            int lw = mc.fontRendererObj.getStringWidth(label);

            if (background.isEnabled()) {
                RenderUtil.drawRoundedRect(x - p, y - p, lw + p * 2 + 2, fh + p * 2, HudTheme.RADIUS, HudTheme.BG);
            }
            mc.fontRendererObj.drawStringWithShadow(label, x + 1, y, HudTheme.TEXT);
        }
    }
}

package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Server Address — Lunar-style compact inline pill.
 * Shows the current server IP or "Singleplayer".
 */
public class ServerAddress extends Module {

    private final BooleanSetting background = register(new BooleanSetting("Background", true));
    private final BooleanSetting showLabel  = register(new BooleanSetting("Show Label", false));

    public ServerAddress() {
        super("Server Address", Category.HUD, "Shows the current server IP.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;

        String address;
        ServerData data = mc.getCurrentServerData();
        if (data != null)         address = data.serverIP;
        else if (mc.isSingleplayer()) address = "Singleplayer";
        else                         return;

        String label = showLabel.isEnabled() ? "Server: " + address : address;

        int x = (int) getPosX(), y = (int) getPosY();
        int lw = mc.fontRendererObj.getStringWidth(label);
        int p  = HudTheme.PADDING;

        if (background.isEnabled()) {
            RenderUtil.drawRoundedRect(x - p, y - p, lw + p * 2 + 2, mc.fontRendererObj.FONT_HEIGHT + p * 2, HudTheme.RADIUS, HudTheme.BG);
        }

        mc.fontRendererObj.drawStringWithShadow(label, x + 1, y, HudTheme.TEXT_DIM);
    }
}

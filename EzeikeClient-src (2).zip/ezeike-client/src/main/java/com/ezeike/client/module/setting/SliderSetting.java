package com.ezeike.client.module.setting;

public class SliderSetting extends Setting<Double> {

    private final double min;
    private final double max;
    private final double step;

    public SliderSetting(String name, String description, double defaultValue,
                         double min, double max, double step) {
        super(name, description, defaultValue);
        this.min  = min;
        this.max  = max;
        this.step = step;
    }

    public SliderSetting(String name, double defaultValue, double min, double max) {
        this(name, "", defaultValue, min, max, 0.1);
    }

    public double getMin()  { return min; }
    public double getMax()  { return max; }
    public double getStep() { return step; }

    @Override
    public void setValue(Double v) {
        this.value = Math.max(min, Math.min(max, v));
    }

    /** Returns a 0–1 normalised fraction for slider rendering. */
    public double getFraction() {
        return (value - min) / (max - min);
    }

    public void setFromFraction(double frac) {
        setValue(min + frac * (max - min));
    }

    @Override
    public String serialise() { return Double.toString(value); }

    @Override
    public void deserialise(String raw) {
        try { setValue(Double.parseDouble(raw.trim())); }
        catch (NumberFormatException ignored) {}
    }
}

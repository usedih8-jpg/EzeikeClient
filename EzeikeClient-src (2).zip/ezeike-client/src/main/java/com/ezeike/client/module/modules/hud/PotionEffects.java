package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.module.setting.ModeSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.*;

/**
 * Potion Effects — Lunar-style clean pill list.
 *
 * Each row looks like:
 *   ┌─────────────────────────────┐
 *   │ ● Speed II            0:30  │    ← coloured dot, name+amp, right-aligned timer
 *   │ ● Strength I          1:45  │
 *   └─────────────────────────────┘
 *
 * Harmful effects: red dot.  Beneficial: green dot.  Neutral: grey dot.
 * The timer turns yellow when < 10 s and red when < 5 s.
 */
public class PotionEffects extends Module {

    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private final ModeSetting    layout  = register(new ModeSetting("Layout", "Vertical", "Vertical", "Horizontal"));
    private final BooleanSetting showAmp = register(new BooleanSetting("Amplifier", true));
    private final BooleanSetting bg      = register(new BooleanSetting("Background", true));

    // Card fixed width so the timer column is always right-aligned
    private static final int CARD_W = 120;
    private static final int ROW_H  = 11;
    private static final int PAD    = 3;

    public PotionEffects() {
        super("Potion Effects", Category.HUD, "Lunar-style active effect list with timers.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.thePlayer == null) return;

        List<PotionEffect> effects = new ArrayList<>(mc.thePlayer.getActivePotionEffects());
        if (effects.isEmpty()) return;
        effects.sort(Comparator.comparingInt(PotionEffect::getDuration).reversed());

        int x = (int) getPosX(), y = (int) getPosY();
        boolean vertical = layout.is("Vertical");

        // Card background spans all rows
        if (bg.isEnabled() && vertical) {
            int cardH = ROW_H * effects.size() + PAD * 2;
            RenderUtil.drawRoundedRect(x, y, CARD_W, cardH, HudTheme.RADIUS, HudTheme.BG);
        }

        int fh = mc.fontRendererObj.FONT_HEIGHT;

        for (int i = 0; i < effects.size(); i++) {
            PotionEffect eff    = effects.get(i);
            Potion       potion = Potion.potionTypes[eff.getPotionID()];
            if (potion == null) continue;

            int secs   = eff.getDuration() / 20;
            String timer = String.format("%d:%02d", secs / 60, secs % 60);

            // Amplifier Roman numeral (only if amp > 0)
            String amp = (showAmp.isEnabled() && eff.getAmplifier() > 0)
                ? " " + (eff.getAmplifier() < ROMAN.length ? ROMAN[eff.getAmplifier() + 1] : (eff.getAmplifier() + 1))
                : "";

            // Clean name: strip "potion.effect." prefix, title-case
            String rawName = potion.getName().replace("potion.effect.", "");
            String name    = Character.toUpperCase(rawName.charAt(0)) + rawName.substring(1) + amp;

            // Dot colour
            int dotColor = potion.isBadEffect() ? HudTheme.BAR_LOW : HudTheme.GOOD;

            // Timer colour
            int timerColor = secs > 10 ? HudTheme.TEXT_DIM : secs > 5 ? HudTheme.OK : HudTheme.BAD;

            int rx = vertical ? x + PAD : x + (CARD_W + 4) * i;
            int ry = vertical ? y + PAD + ROW_H * i : y;

            if (!vertical && bg.isEnabled()) {
                int rw = mc.fontRendererObj.getStringWidth(name) + mc.fontRendererObj.getStringWidth(timer) + 22;
                RenderUtil.drawRoundedRect(rx - PAD, ry - 1, rw, ROW_H + 2, HudTheme.RADIUS, HudTheme.BG);
            }

            // Coloured dot  "●"
            mc.fontRendererObj.drawStringWithShadow("●", rx, ry + (ROW_H - fh) / 2f, dotColor);

            // Effect name
            mc.fontRendererObj.drawStringWithShadow(name, rx + 8, ry + (ROW_H - fh) / 2f, HudTheme.TEXT);

            // Timer — right-aligned inside the card
            if (vertical) {
                int tw = mc.fontRendererObj.getStringWidth(timer);
                mc.fontRendererObj.drawStringWithShadow(timer, x + CARD_W - PAD - tw, ry + (ROW_H - fh) / 2f, timerColor);
            } else {
                mc.fontRendererObj.drawStringWithShadow("  " + timer, rx + 8 + mc.fontRendererObj.getStringWidth(name), ry + (ROW_H - fh) / 2f, timerColor);
            }
        }
    }
}

package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.module.setting.ModeSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * FPS Display — Lunar-style compact card.
 *
 * Modes:
 *   Compact  — "420 FPS"   (single value, coloured)
 *   Labelled — "FPS: 420"  (label + value)
 *   Number   — "420"       (raw number only)
 */
public class FPSDisplay extends Module {

    private final BooleanSetting background = register(new BooleanSetting("Background", true));
    private final ModeSetting    mode       = register(new ModeSetting("Mode", "Compact", "Compact", "Labelled", "Number"));

    public FPSDisplay() {
        super("FPS Display", Category.HUD, "Shows frames per second.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;

        int fps = Minecraft.getDebugFPS();
        int fpsColor = fps >= 60 ? HudTheme.GOOD : fps >= 30 ? HudTheme.OK : HudTheme.BAD;

        String label;
        switch (mode.getValue()) {
            case "Labelled": label = "FPS: " + fps; break;
            case "Number":   label = String.valueOf(fps); break;
            default:         label = fps + " FPS"; break;
        }

        int x = (int) getPosX(), y = (int) getPosY();
        int lw = mc.fontRendererObj.getStringWidth(label);
        int p  = HudTheme.PADDING;

        if (background.isEnabled()) {
            RenderUtil.drawRoundedRect(x - p, y - p, lw + p * 2 + 2, mc.fontRendererObj.FONT_HEIGHT + p * 2, HudTheme.RADIUS, HudTheme.BG);
        }

        mc.fontRendererObj.drawStringWithShadow(label, x + 1, y, fpsColor);
    }
}

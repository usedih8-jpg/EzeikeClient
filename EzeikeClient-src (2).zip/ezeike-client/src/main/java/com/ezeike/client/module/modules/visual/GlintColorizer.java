package com.ezeike.client.module.modules.visual;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.ColorSetting;
import com.ezeike.client.module.setting.ModeSetting;
import com.ezeike.client.module.setting.SliderSetting;
import com.ezeike.client.util.RenderUtil;

/**
 * Glint Colorizer — replaces the standard golden enchantment glint with a
 * custom colour (default: Ezeike purple) or a chroma rainbow cycle.
 *
 * The actual colour injection is performed via a mixin targeting
 * {@code RenderItem#renderEffect}.  This module stores the desired state;
 * the mixin reads it via the static {@link #getGlintColor()} accessor.
 *
 * To wire up the mixin:
 *   1. Create a @Mixin(RenderItem.class) class.
 *   2. In the @Inject into renderEffect, call GlStateManager.color()
 *      using the values from {@link #getGlintColor()}.
 */
public class GlintColorizer extends Module {

    private static GlintColorizer INSTANCE;

    private final ModeSetting  mode  = register(new ModeSetting("Mode",  "Glint style.",
        "PURPLE", "PURPLE", "CHROMA", "CUSTOM"));
    private final ColorSetting color = register(new ColorSetting("Color",
        "Custom ARGB glint color.", 0xFF4ECDC4));
    private final SliderSetting speed = register(new SliderSetting("Speed",
        "Chroma cycle duration (ms).", 5000, 1000, 15000, 500));

    public GlintColorizer() {
        super("Glint Colorizer", Category.VISUAL, "Changes enchanted item glint colour.");
        INSTANCE = this;
    }

    /**
     * Called by the mixin each frame to determine which colour to apply.
     * @return packed ARGB int.
     */
    public static int getGlintColor() {
        if (INSTANCE == null || !INSTANCE.isEnabled()) return 0xFFFF8000; // vanilla gold fallback

        switch (INSTANCE.mode.getValue()) {
            case "CHROMA":
                return RenderUtil.chromaColor((long) INSTANCE.speed.getValue().intValue());
            case "CUSTOM":
                return INSTANCE.color.getValue();
            default: // TEAL
                return 0xFF4ECDC4;
        }
    }
}

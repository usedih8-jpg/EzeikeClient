package com.ezeike.client.module.modules.combat;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.ColorSetting;
import com.ezeike.client.module.setting.SliderSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * Damage Tint — draws a vignette overlay that pulses red (or custom colour)
 * when the player's health falls below a configurable threshold.
 *
 * The heartbeat effect is triggered by cycling the vignette alpha between
 * a high and low value at a rate proportional to how low the player's health is.
 */
public class DamageTint extends Module {

    private final SliderSetting  threshold    = register(new SliderSetting("Threshold", "Health % to activate.", 50, 10, 100, 5));
    private final ColorSetting   tintColor    = register(new ColorSetting("Tint Color", 0xAAFF0000));
    private final SliderSetting  maxAlpha     = register(new SliderSetting("Max Alpha", 180, 0, 255, 5));
    private final SliderSetting  pulseSpeed   = register(new SliderSetting("Pulse Speed", 3.0, 0.5, 10.0, 0.5));

    private float currentAlpha = 0f;
    private float direction    = 1f;   // 1 = fading in, -1 = fading out

    public DamageTint() {
        super("Damage Tint", Category.COMBAT, "Red vignette and heartbeat effect at low health.");
    }

    @Override
    public void onTick() {
        if (mc.thePlayer == null) return;

        float hpPct = (mc.thePlayer.getHealth() / mc.thePlayer.getMaxHealth()) * 100f;
        float thresh = (float) threshold.getValue();

        if (hpPct < thresh) {
            // Pulse speed scales with how low health is
            float speedMult = 1f + (thresh - hpPct) / thresh * (float) pulseSpeed.getValue();
            currentAlpha += direction * speedMult;
            if (currentAlpha >= maxAlpha.getValue()) { currentAlpha = (float) maxAlpha.getValue(); direction = -1f; }
            if (currentAlpha <= 20f)                 { currentAlpha = 20f;                         direction =  1f; }
        } else {
            currentAlpha = Math.max(0, currentAlpha - 5f);
        }
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (currentAlpha <= 0) return;

        ScaledResolution sr = new ScaledResolution(mc);
        int sw = sr.getScaledWidth(), sh = sr.getScaledHeight();

        int base = tintColor.getValue() & 0x00FFFFFF;
        int tint = RenderUtil.withAlpha(base | 0xFF000000, (int) currentAlpha);

        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.disableTexture2D();

        // Vignette — four gradient strips from each edge inward
        int vigW = sw / 4;
        RenderUtil.drawGradientH(0,       0,  vigW, sh, tint, 0x00000000);
        RenderUtil.drawGradientH(sw-vigW, 0,  vigW, sh, 0x00000000, tint);
        RenderUtil.drawGradientV(0,       0,  sw, vigW, tint, 0x00000000);
        RenderUtil.drawGradientV(0, sh-vigW,  sw, vigW, 0x00000000, tint);

        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }
}

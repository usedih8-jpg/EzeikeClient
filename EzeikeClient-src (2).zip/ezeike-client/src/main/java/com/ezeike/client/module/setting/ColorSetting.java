package com.ezeike.client.module.setting;

/**
 * An ARGB colour setting.
 * Value is stored as a packed {@code int} (0xAARRGGBB).
 */
public class ColorSetting extends Setting<Integer> {

    public ColorSetting(String name, String description, int defaultArgb) {
        super(name, description, defaultArgb);
    }

    public ColorSetting(String name, int defaultArgb) {
        super(name, defaultArgb);
    }

    public int getAlpha() { return (value >> 24) & 0xFF; }
    public int getRed()   { return (value >> 16) & 0xFF; }
    public int getGreen() { return (value >> 8)  & 0xFF; }
    public int getBlue()  { return  value        & 0xFF; }

    @Override
    public String serialise() { return Integer.toHexString(value); }

    @Override
    public void deserialise(String raw) {
        try { value = (int) Long.parseLong(raw.trim(), 16); }
        catch (NumberFormatException ignored) {}
    }
}

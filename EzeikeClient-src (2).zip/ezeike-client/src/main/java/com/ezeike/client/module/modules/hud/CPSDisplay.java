package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * CPS Display — Lunar-style.
 *
 * Shows left and right clicks-per-second in a single compact card:
 *   "8 | 4 CPS"
 * or split into two lines if the user prefers.
 */
public class CPSDisplay extends Module {

    private final BooleanSetting background = register(new BooleanSetting("Background", true));
    private final BooleanSetting showRight  = register(new BooleanSetting("Show RMB CPS", true));

    private final Deque<Long> leftClicks  = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();

    public CPSDisplay() {
        super("CPS Display", Category.HUD, "Shows clicks per second.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onMouseInput(InputEvent.MouseInputEvent event) {
        if (!Mouse.getEventButtonState()) return;
        long now = System.currentTimeMillis();
        int btn  = Mouse.getEventButton();
        if (btn == 0) leftClicks.addLast(now);
        if (btn == 1) rightClicks.addLast(now);
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;

        long now    = System.currentTimeMillis();
        long cutoff = now - 1000L;
        while (!leftClicks.isEmpty()  && leftClicks.peekFirst()  < cutoff) leftClicks.pollFirst();
        while (!rightClicks.isEmpty() && rightClicks.peekFirst() < cutoff) rightClicks.pollFirst();

        int lCps = leftClicks.size();
        int rCps = rightClicks.size();

        // Lunar layout: "8 | 4 CPS"  or just "8 CPS"
        String label = showRight.isEnabled()
            ? lCps + " | " + rCps + " CPS"
            : lCps + " CPS";

        int x = (int) getPosX(), y = (int) getPosY();
        int lw = mc.fontRendererObj.getStringWidth(label);
        int p  = HudTheme.PADDING;

        if (background.isEnabled()) {
            RenderUtil.drawRoundedRect(x - p, y - p, lw + p * 2 + 2, mc.fontRendererObj.FONT_HEIGHT + p * 2, HudTheme.RADIUS, HudTheme.BG);
        }

        mc.fontRendererObj.drawStringWithShadow(label, x + 1, y, HudTheme.TEXT);
    }
}

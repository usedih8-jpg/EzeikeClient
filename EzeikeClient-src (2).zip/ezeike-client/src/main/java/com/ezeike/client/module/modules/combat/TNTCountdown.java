package com.ezeike.client.module.modules.combat;

import com.ezeike.client.EzeikeClient;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.ColorSetting;
import com.ezeike.client.module.setting.SliderSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.List;

/**
 * TNT Countdown — renders a floating timer above each ignited TNT entity
 * showing the remaining fuse time in seconds with one decimal place.
 *
 * Text is billboard-rendered (always faces the camera) and colour-coded:
 *   • Green  → > 2s
 *   • Yellow → 1–2s
 *   • Red    → < 1s
 */
public class TNTCountdown extends Module {

    private final SliderSetting  maxDist = register(new SliderSetting("Max Distance", 32, 8, 128, 4));
    private final ColorSetting   color   = register(new ColorSetting("Text Color", 0xFFFFFFFF));

    public TNTCountdown() {
        super("TNT Countdown", Category.COMBAT, "Shows fuse timers above lit TNT.");
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.theWorld == null || mc.thePlayer == null) return;

        List<EntityTNTPrimed> tntList = mc.theWorld.getEntitiesWithinAABB(
            EntityTNTPrimed.class,
            mc.thePlayer.getEntityBoundingBox().expand(maxDist.getValue(), maxDist.getValue(), maxDist.getValue())
        );

        if (tntList.isEmpty()) return;

        float pt = event.partialTicks;
        double px = mc.thePlayer.lastTickPosX + (mc.thePlayer.posX - mc.thePlayer.lastTickPosX) * pt;
        double py = mc.thePlayer.lastTickPosY + (mc.thePlayer.posY - mc.thePlayer.lastTickPosY) * pt;
        double pz = mc.thePlayer.lastTickPosZ + (mc.thePlayer.posZ - mc.thePlayer.lastTickPosZ) * pt;

        GlStateManager.pushMatrix();
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        for (EntityTNTPrimed tnt : tntList) {
            float fuse    = tnt.fuse;           // ticks remaining
            float seconds = fuse / 20f;
            String label  = String.format("%.1fs", seconds);

            int textColor = fuse > 40 ? 0xFF55FF55 : fuse > 20 ? 0xFFFFFF55 : 0xFFFF5555;

            double ex = tnt.lastTickPosX + (tnt.posX - tnt.lastTickPosX) * pt - px;
            double ey = tnt.lastTickPosY + (tnt.posY - tnt.lastTickPosY) * pt - py + tnt.height + 0.3;
            double ez = tnt.lastTickPosZ + (tnt.posZ - tnt.lastTickPosZ) * pt - pz;

            GlStateManager.pushMatrix();
            GlStateManager.translate(ex, ey, ez);
            GlStateManager.rotate(-mc.thePlayer.rotationYaw,  0, 1, 0);
            GlStateManager.rotate( mc.thePlayer.rotationPitch, 1, 0, 0);
            float scale = 0.027f;
            GlStateManager.scale(-scale, -scale, scale);

            int lw = mc.fontRendererObj.getStringWidth(label);
            mc.fontRendererObj.drawStringWithShadow(label, -lw / 2f, 0, textColor);

            GlStateManager.popMatrix();
        }

        GlStateManager.disableBlend();
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }
}

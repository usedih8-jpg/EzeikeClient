package com.ezeike.client.module.modules.combat;

import com.ezeike.client.EzeikeClient;
import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.module.setting.ColorSetting;
import com.ezeike.client.module.setting.SliderSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.List;

/**
 * NameTags — replaces vanilla nametags with custom high-visibility 2D tags
 * rendered above each player, including:
 *   • Player name
 *   • Health bar (green → red as health drops)
 *   • Distance in metres
 *
 * Tags always face the camera (billboard rendering) and scale with distance.
 */
public class NameTags extends Module {

    private final SliderSetting  maxDist    = register(new SliderSetting("Max Distance", 64, 16, 256, 8));
    private final BooleanSetting showHealth = register(new BooleanSetting("Health Bar", true));
    private final BooleanSetting showDist   = register(new BooleanSetting("Distance", true));
    private final ColorSetting   bgColor    = register(new ColorSetting("Background", 0xBB000000));

    public NameTags() {
        super("NameTags", Category.COMBAT, "Custom player nametags with health bars.");
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.theWorld == null || mc.thePlayer == null) return;

        float pt = event.partialTicks;
        double px = mc.thePlayer.lastTickPosX + (mc.thePlayer.posX - mc.thePlayer.lastTickPosX) * pt;
        double py = mc.thePlayer.lastTickPosY + (mc.thePlayer.posY - mc.thePlayer.lastTickPosY) * pt;
        double pz = mc.thePlayer.lastTickPosZ + (mc.thePlayer.posZ - mc.thePlayer.lastTickPosZ) * pt;

        List<EntityPlayer> players = mc.theWorld.playerEntities;
        double maxD = maxDist.getValue();

        GlStateManager.pushMatrix();
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        for (EntityPlayer player : players) {
            if (player == mc.thePlayer) continue;

            double ex = player.lastTickPosX + (player.posX - player.lastTickPosX) * pt - px;
            double ey = player.lastTickPosY + (player.posY - player.lastTickPosY) * pt - py + player.height + 0.5;
            double ez = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * pt - pz;

            double dist = Math.sqrt(ex * ex + ey * ey + ez * ez);
            if (dist > maxD) continue;

            GlStateManager.pushMatrix();
            GlStateManager.translate(ex, ey, ez);
            GlStateManager.rotate(-mc.thePlayer.rotationYaw,  0, 1, 0);
            GlStateManager.rotate( mc.thePlayer.rotationPitch, 1, 0, 0);

            float scale = 0.025f + (float)(dist * 0.001f);
            GlStateManager.scale(-scale, -scale, scale);

            // Build label
            String name = player.getName();
            String distStr = showDist.isEnabled() ? String.format(" [%.0fm]", dist) : "";
            String label = name + distStr;

            int lw = mc.fontRendererObj.getStringWidth(label);
            int lh = mc.fontRendererObj.FONT_HEIGHT;
            int bw = lw + 8;
            int bh = showHealth.isEnabled() ? lh + 8 : lh + 4;

            // Background
            RenderUtil.drawRoundedRect(-bw / 2f, -bh / 2f, bw, bh, 3, bgColor.getValue());
            RenderUtil.drawOutline(-bw / 2f, -bh / 2f, bw, bh, 1f, HudTheme.EDGE);

            // Name
            mc.fontRendererObj.drawStringWithShadow(label, -lw / 2f, -(lh / 2f) - (showHealth.isEnabled() ? 2 : 0), 0xFFFFFFFF);

            // Health bar
            if (showHealth.isEnabled()) {
                float maxHp = player.getMaxHealth();
                float curHp = player.getHealth();
                float frac  = curHp / maxHp;

                int barW = bw - 4;
                int barH = 3;
                int barX = -barW / 2;
                int barY = lh / 2 + 1;

                RenderUtil.drawRect(barX, barY, barW, barH, 0xFF333333);
                int barColor = frac > 0.6f ? 0xFF55FF55 : frac > 0.3f ? 0xFFFFFF55 : 0xFFFF5555;
                RenderUtil.drawRect(barX, barY, (int)(barW * frac), barH, barColor);
            }

            GlStateManager.popMatrix();
        }

        GlStateManager.disableBlend();
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }
}

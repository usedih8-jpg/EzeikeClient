package com.ezeike.client.module;

import com.ezeike.client.EzeikeClient;
import com.ezeike.client.module.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for every feature module in Ezeike Client.
 *
 * A Module is a self-contained, toggleable unit of functionality.
 * Each module:
 *   - Has a unique name, category, and optional description.
 *   - Owns a list of {@link Setting} objects that drive its configuration.
 *   - Registers itself on the Forge event bus when enabled and
 *     unregisters when disabled, so disabled modules have zero overhead.
 *   - Stores a HUD position (x, y) and scale for renderable modules.
 *   - Declares whether it renders on the HUD ({@link #isHudElement()}).
 */
public abstract class Module {

    // ---------------------------------------------------------------  Identity

    private final String name;
    private final Category category;
    private final String description;

    // ---------------------------------------------------------------  State

    private boolean enabled   = false;
    private boolean listening = false;   // currently registered on the event bus?

    // ---------------------------------------------------------------  HUD placement

    /** Screen X position (pixels from left). Used by HUD elements only. */
    private double posX = 10;
    /** Screen Y position (pixels from top). Used by HUD elements only. */
    private double posY = 10;
    /** Render scale multiplier (1.0 = default). */
    private double scale = 1.0;

    // ---------------------------------------------------------------  Settings

    protected final List<Setting<?>> settings = new ArrayList<>();

    // ---------------------------------------------------------------  Minecraft shortcut

    protected static final Minecraft mc = Minecraft.getMinecraft();

    // ---------------------------------------------------------------  Constructor

    /**
     * @param name        Human-readable name shown in the GUI.
     * @param category    Logical grouping for the module list.
     * @param description One-line description shown on hover.
     */
    protected Module(String name, Category category, String description) {
        this.name        = name;
        this.category    = category;
        this.description = description;
    }

    protected Module(String name, Category category) {
        this(name, category, "");
    }

    // ---------------------------------------------------------------  Lifecycle hooks (override in subclasses)

    /** Called once when the module is first registered with the ModuleManager. */
    public void onLoad() {}

    /** Called every Forge client tick (START phase) while the module is enabled. */
    public void onTick() {}

    /** Called when the module transitions from disabled → enabled. */
    public void onEnable() {}

    /** Called when the module transitions from enabled → disabled. */
    public void onDisable() {}

    // ---------------------------------------------------------------  Toggle logic

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean state) {
        if (state == enabled) return;
        enabled = state;

        if (enabled) {
            if (!listening) {
                MinecraftForge.EVENT_BUS.register(this);
                listening = true;
            }
            onEnable();
        } else {
            if (listening) {
                MinecraftForge.EVENT_BUS.unregister(this);
                listening = false;
            }
            onDisable();
        }
    }

    // ---------------------------------------------------------------  Settings helpers

    protected <T extends Setting<?>> T register(T setting) {
        settings.add(setting);
        return setting;
    }

    // ---------------------------------------------------------------  HUD element flag

    /**
     * Override and return {@code true} in modules that render a HUD overlay.
     * The HUD Editor will only show/allow dragging of modules for which
     * this returns {@code true}.
     */
    public boolean isHudElement() { return false; }

    // ---------------------------------------------------------------  Getters / setters

    public String    getName()        { return name; }
    public Category  getCategory()    { return category; }
    public String    getDescription() { return description; }
    public boolean   isEnabled()      { return enabled; }
    public List<Setting<?>> getSettings() { return settings; }

    public double getPosX()  { return posX; }
    public double getPosY()  { return posY; }
    public double getScale() { return scale; }

    public void setPosX(double x)  { this.posX  = x; }
    public void setPosY(double y)  { this.posY  = y; }
    public void setScale(double s) { this.scale = Math.max(0.5, Math.min(3.0, s)); }

    // ---------------------------------------------------------------  toString

    @Override
    public String toString() {
        return "[" + category.name() + "] " + name + " (" + (enabled ? "ON" : "OFF") + ")";
    }

    // ---------------------------------------------------------------  Category enum

    public enum Category {
        VISUAL("Visual"),
        HUD("HUD"),
        COMBAT("Combat"),
        MOVEMENT("Movement"),
        QOL("Quality of Life"),
        MISC("Misc");

        private final String displayName;
        Category(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }
}

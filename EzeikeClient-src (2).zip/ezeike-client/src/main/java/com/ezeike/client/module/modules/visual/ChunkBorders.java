package com.ezeike.client.module.modules.visual;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.ColorSetting;
import com.ezeike.client.module.setting.SliderSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * Chunk Borders — renders vertical lines at chunk boundaries (every 16 blocks)
 * in the XZ plane, extending from Y=0 to Y=256.
 *
 * The purple colour matches the Ezeike theme by default.
 */
public class ChunkBorders extends Module {

    private final SliderSetting radius = register(new SliderSetting("Radius", "Chunks to render around player.", 2, 1, 8, 1));
    private final ColorSetting  color  = register(new ColorSetting("Color", "Border line colour.", 0xAA4ECDC4));

    public ChunkBorders() {
        super("Chunk Borders", Category.VISUAL, "Shows chunk boundary lines.");
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        Entity cam = mc.getRenderViewEntity();
        if (cam == null) return;

        double px = cam.lastTickPosX + (cam.posX - cam.lastTickPosX) * event.partialTicks;
        double py = cam.lastTickPosY + (cam.posY - cam.lastTickPosY) * event.partialTicks;
        double pz = cam.lastTickPosZ + (cam.posZ - cam.lastTickPosZ) * event.partialTicks;

        // Snap to chunk origin
        int chunkX = (int) Math.floor(px / 16) * 16;
        int chunkZ = (int) Math.floor(pz / 16) * 16;
        int rad    = (int) radius.getValue();

        int c = color.getValue();
        float a = ((c >> 24) & 0xFF) / 255f, r = ((c >> 16) & 0xFF) / 255f,
              g = ((c >>  8) & 0xFF) / 255f, b = ( c        & 0xFF) / 255f;

        GlStateManager.pushMatrix();
        GlStateManager.translate(-px, -py, -pz);
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.disableDepth();
        GL11.glLineWidth(1.5f);

        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);

        for (int cx = -rad; cx <= rad + 1; cx++) {
            double lx = (chunkX + cx * 16);
            wr.pos(lx, 0,   pz - rad * 16).color(r, g, b, a).endVertex();
            wr.pos(lx, 256, pz - rad * 16).color(r, g, b, a).endVertex();
            wr.pos(lx, 0,   pz + (rad + 1) * 16).color(r, g, b, a).endVertex();
            wr.pos(lx, 256, pz + (rad + 1) * 16).color(r, g, b, a).endVertex();
        }

        for (int cz = -rad; cz <= rad + 1; cz++) {
            double lz = (chunkZ + cz * 16);
            wr.pos(px - rad * 16, 0,   lz).color(r, g, b, a).endVertex();
            wr.pos(px - rad * 16, 256, lz).color(r, g, b, a).endVertex();
            wr.pos(px + (rad + 1) * 16, 0,   lz).color(r, g, b, a).endVertex();
            wr.pos(px + (rad + 1) * 16, 256, lz).color(r, g, b, a).endVertex();
        }

        tess.draw();

        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.popMatrix();
    }
}

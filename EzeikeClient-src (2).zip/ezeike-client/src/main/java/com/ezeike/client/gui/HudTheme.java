package com.ezeike.client.gui;

/**
 * Ezeike Client — HUD Theme
 *
 * Palette: Summer Night / Moon Chill
 *
 *   Deep ocean navy backgrounds
 *   Moonlight silver text
 *   Cool teal accent (like light on night water)
 *   Warm golden "ok" tier — feels like a citronella candle
 *   Soft coral for warnings / low health
 *   Everything breathes — low contrast, nothing shouts
 */
public final class HudTheme {

    private HudTheme() {}

    // ---------------------------------------------------------------  Backgrounds
    /** Main card background — deep navy at ~55% opacity. */
    public static final int BG             = 0x8C0D1B2A;
    /** Slightly lighter variant for nested rows. */
    public static final int BG_ROW_HOVER   = 0x1ACBDDF5;
    /** Deeper panel bg used for sidebars / scoreboard title. */
    public static final int BG_TITLE       = 0xAA091422;

    // ---------------------------------------------------------------  Borders / edges
    /** Thin card edge — pale moonlight blue, barely visible. */
    public static final int EDGE           = 0x35C8D8E8;
    /** Hover edge — soft silver. */
    public static final int EDGE_HOVER     = 0x70C8D8E8;

    // ---------------------------------------------------------------  Text
    /** Primary text — moonlight white with a blue tint. */
    public static final int TEXT           = 0xFFE8F0F8;
    /** Secondary / dim text — cool blue-grey. */
    public static final int TEXT_DIM       = 0xFF8BA3BF;
    /** Very muted — for numbers, metadata. */
    public static final int TEXT_DARK      = 0xFF4A6080;

    // ---------------------------------------------------------------  Performance / value tiers
    /** Good (≥60 fps / ≤80 ms) — minty teal. */
    public static final int GOOD           = 0xFF52E3C2;
    /** Ok (30-60 fps / 80-150 ms) — warm summer gold. */
    public static final int OK             = 0xFFFFD166;
    /** Bad (<30 fps / >150 ms) — soft coral. */
    public static final int BAD            = 0xFFEF767A;

    // ---------------------------------------------------------------  Accent (teal / moonlight)
    /** Primary accent — teal, like moonlight on ocean water. */
    public static final int ACCENT         = 0xFF4ECDC4;
    /** Brighter accent for active states. */
    public static final int ACCENT_BRIGHT  = 0xFF7EECEA;
    /** Soft sky blue — secondary accent. */
    public static final int ACCENT_SKY     = 0xFF89CFF0;

    // ---------------------------------------------------------------  Keystroke keys
    /** Idle key background — dark midnight navy. */
    public static final int KEY_BG         = 0xCC0A1220;
    /** Idle key border — muted blue-grey. */
    public static final int KEY_BORDER     = 0xFF2A3F5F;
    /** Pressed key fill — moonlight silver. */
    public static final int KEY_ACTIVE_BG  = 0xFFC8D8E8;
    /** Text on pressed key — dark navy for contrast on silver. */
    public static final int KEY_ACTIVE_TXT = 0xFF0A1220;
    /** Text on idle key — muted steel blue. */
    public static final int KEY_IDLE_TXT   = 0xFF4A6080;

    // ---------------------------------------------------------------  Health / armor bars
    /** Bar track background. */
    public static final int BAR_BG         = 0xFF1A2A3A;
    /** Full / high health — cool teal green. */
    public static final int BAR_HIGH       = 0xFF52E3C2;
    /** Mid health — warm gold. */
    public static final int BAR_MED        = 0xFFFFD166;
    /** Low health — soft coral. */
    public static final int BAR_LOW        = 0xFFEF767A;

    // ---------------------------------------------------------------  Layout
    /** Corner radius for all rounded rects. */
    public static final float RADIUS       = 3f;
    /** Inner padding between card edge and text (px). */
    public static final int PADDING        = 2;
    /** Standard row line height. */
    public static final int LINE_H         = 10;
}

package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.module.setting.ModeSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Armor Status — Lunar-style clean item row.
 *
 * Layout (Vertical mode):           Layout (Horizontal mode):
 *   ┌──────────────────┐              ┌────┬────┬────┬────┬────┐
 *   │ [Helm]  100%     │              │Hlm │Cst │Leg │Boo │Hnd │
 *   │ [Chest]  89%     │              └────┴────┴────┴────┴────┘
 *   │ [Legs]   72%     │
 *   │ [Boots] 100%     │
 *   │ [Hand]  Gap-pple │
 *   └──────────────────┘
 *
 * Durability bar appears beneath each icon: a thin coloured strip
 * that turns yellow → red as durability drops (exactly Lunar behaviour).
 */
public class ArmorStatus extends Module {

    private static final int ICON = 16;
    private static final int GAP  = 2;
    private static final int BAR_H = 2;

    private final BooleanSetting showDurability = register(new BooleanSetting("Durability Bar",    true));
    private final BooleanSetting showPct        = register(new BooleanSetting("Durability %",      true));
    private final BooleanSetting showHeld       = register(new BooleanSetting("Held Item",         true));
    private final ModeSetting    layout         = register(new ModeSetting("Layout", "Vertical", "Vertical", "Horizontal"));

    public ArmorStatus() {
        super("Armor Status", Category.HUD, "Armor icons with Lunar-style durability bars.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.thePlayer == null) return;

        // Collect non-null stacks: helmet(3), chestplate(2), leggings(1), boots(0), held
        int[] armorSlots = {3, 2, 1, 0};
        boolean horizontal = layout.is("Horizontal");
        int x = (int) getPosX(), y = (int) getPosY();
        int col = 0;

        for (int slot : armorSlots) {
            ItemStack stack = mc.thePlayer.inventory.armorInventory[slot];
            if (stack == null) continue;
            if (horizontal) renderItemH(stack, x + col * (ICON + GAP), y);
            else             renderItemV(stack, x, y + col * (ICON + GAP + BAR_H + (showPct.isEnabled() ? 9 : 0) + GAP));
            col++;
        }

        if (showHeld.isEnabled()) {
            ItemStack held = mc.thePlayer.getHeldItem();
            if (held != null) {
                if (horizontal) renderItemH(held, x + col * (ICON + GAP + 4), y);
                else             renderItemV(held, x, y + col * (ICON + GAP + BAR_H + (showPct.isEnabled() ? 9 : 0) + GAP) + GAP * 2);
            }
        }
    }

    // ---------------------------------------------------------------  Vertical slot (icon + bar + % text below)

    private void renderItemV(ItemStack stack, int x, int y) {
        // Slot background — barely-there dark pill
        RenderUtil.drawRoundedRect(x - 1, y - 1, ICON + 2, ICON + 2, 2, 0x55000000);

        GlStateManager.enableBlend();
        mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
        mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRendererObj, stack, x, y, null);
        GlStateManager.disableBlend();

        if (stack.isItemStackDamageable()) {
            int pct  = durPct(stack);
            int clr  = pct > 60 ? HudTheme.BAR_HIGH : pct > 30 ? HudTheme.BAR_MED : HudTheme.BAR_LOW;

            if (showDurability.isEnabled()) {
                int barY = y + ICON + 1;
                RenderUtil.drawRect(x, barY, ICON, BAR_H, HudTheme.BAR_BG);
                RenderUtil.drawRect(x, barY, (int)(ICON * pct / 100f), BAR_H, clr);
            }
            if (showPct.isEnabled()) {
                String pctStr = pct + "%";
                mc.fontRendererObj.drawStringWithShadow(pctStr,
                    x + (ICON - mc.fontRendererObj.getStringWidth(pctStr)) / 2f,
                    y + ICON + BAR_H + 2, clr);
            }
        }
    }

    // ---------------------------------------------------------------  Horizontal slot (icon + bar beneath icon)

    private void renderItemH(ItemStack stack, int x, int y) {
        RenderUtil.drawRoundedRect(x - 1, y - 1, ICON + 2, ICON + BAR_H + 4, 2, 0x55000000);

        GlStateManager.enableBlend();
        mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
        mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRendererObj, stack, x, y, null);
        GlStateManager.disableBlend();

        if (showDurability.isEnabled() && stack.isItemStackDamageable()) {
            int pct  = durPct(stack);
            int clr  = pct > 60 ? HudTheme.BAR_HIGH : pct > 30 ? HudTheme.BAR_MED : HudTheme.BAR_LOW;
            int barY = y + ICON + 1;
            RenderUtil.drawRect(x, barY, ICON, BAR_H, HudTheme.BAR_BG);
            RenderUtil.drawRect(x, barY, (int)(ICON * pct / 100f), BAR_H, clr);
        }
    }

    private int durPct(ItemStack s) {
        if (s.getMaxDamage() == 0) return 100;
        return (int)(100f * (s.getMaxDamage() - s.getItemDamage()) / s.getMaxDamage());
    }
}

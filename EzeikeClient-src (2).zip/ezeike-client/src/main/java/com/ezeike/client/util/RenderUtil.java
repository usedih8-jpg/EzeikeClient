package com.ezeike.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

import java.awt.*;

/**
 * Utility helpers for 2D GUI rendering used by HUD modules and the editor.
 *
 * All colour arguments are packed ARGB ints (0xAARRGGBB).
 */
public final class RenderUtil {

    private RenderUtil() {}

    private static final Minecraft mc = Minecraft.getMinecraft();

    // ---------------------------------------------------------------  Solid rectangles

    /** Draws a solid rectangle with a single colour. */
    public static void drawRect(double x, double y, double w, double h, int color) {
        Gui.drawRect((int) x, (int) y, (int)(x + w), (int)(y + h), color);
    }

    /** Draws a rectangle with only an outline (no fill). */
    public static void drawOutline(double x, double y, double w, double h, float lineWidth, int color) {
        GL11.glLineWidth(lineWidth);
        GlStateManager.disableTexture2D();
        enableAlpha();

        float a = ((color >> 24) & 0xFF) / 255f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8)  & 0xFF) / 255f;
        float b = ( color        & 0xFF) / 255f;

        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(GL11.GL_LINE_LOOP, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x,     y,     0).color(r, g, b, a).endVertex();
        wr.pos(x + w, y,     0).color(r, g, b, a).endVertex();
        wr.pos(x + w, y + h, 0).color(r, g, b, a).endVertex();
        wr.pos(x,     y + h, 0).color(r, g, b, a).endVertex();
        tess.draw();

        GlStateManager.enableTexture2D();
        disableAlpha();
    }

    // ---------------------------------------------------------------  Gradient rectangles

    /**
     * Vertical gradient from {@code topColor} to {@code bottomColor}.
     */
    public static void drawGradientV(double x, double y, double w, double h,
                                     int topColor, int bottomColor) {
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);

        float a1 = ((topColor    >> 24) & 0xFF) / 255f, r1 = ((topColor    >> 16) & 0xFF) / 255f,
              g1 = ((topColor    >>  8) & 0xFF) / 255f, b1 = ( topColor           & 0xFF) / 255f;
        float a2 = ((bottomColor >> 24) & 0xFF) / 255f, r2 = ((bottomColor >> 16) & 0xFF) / 255f,
              g2 = ((bottomColor >>  8) & 0xFF) / 255f, b2 = ( bottomColor        & 0xFF) / 255f;

        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x,     y,     0).color(r1, g1, b1, a1).endVertex();
        wr.pos(x + w, y,     0).color(r1, g1, b1, a1).endVertex();
        wr.pos(x + w, y + h, 0).color(r2, g2, b2, a2).endVertex();
        wr.pos(x,     y + h, 0).color(r2, g2, b2, a2).endVertex();
        tess.draw();

        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
    }

    /**
     * Horizontal gradient from {@code leftColor} to {@code rightColor}.
     */
    public static void drawGradientH(double x, double y, double w, double h,
                                     int leftColor, int rightColor) {
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);

        float a1 = ((leftColor  >> 24) & 0xFF) / 255f, r1 = ((leftColor  >> 16) & 0xFF) / 255f,
              g1 = ((leftColor  >>  8) & 0xFF) / 255f, b1 = ( leftColor         & 0xFF) / 255f;
        float a2 = ((rightColor >> 24) & 0xFF) / 255f, r2 = ((rightColor >> 16) & 0xFF) / 255f,
              g2 = ((rightColor >>  8) & 0xFF) / 255f, b2 = ( rightColor        & 0xFF) / 255f;

        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x,     y,     0).color(r1, g1, b1, a1).endVertex();
        wr.pos(x + w, y,     0).color(r2, g2, b2, a2).endVertex();
        wr.pos(x + w, y + h, 0).color(r2, g2, b2, a2).endVertex();
        wr.pos(x,     y + h, 0).color(r1, g1, b1, a1).endVertex();
        tess.draw();

        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
    }

    // ---------------------------------------------------------------  Rounded rect helper (approximated via segments)

    /**
     * Draws a filled rounded rectangle by drawing a central rect plus four corner arcs.
     * {@code radius} is the corner arc radius in pixels.
     */
    public static void drawRoundedRect(double x, double y, double w, double h,
                                       double radius, int color) {
        radius = Math.min(radius, Math.min(w, h) / 2.0);

        // Fill interior rects
        drawRect(x + radius, y,          w - radius * 2, h,          color);
        drawRect(x,          y + radius, radius,         h - radius * 2, color);
        drawRect(x + w - radius, y + radius, radius,    h - radius * 2, color);

        float a = ((color >> 24) & 0xFF) / 255f, r = ((color >> 16) & 0xFF) / 255f,
              g = ((color >> 8)  & 0xFF) / 255f, b = ( color        & 0xFF) / 255f;

        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        int segments = 16;
        drawCornerArc(x + radius,         y + radius,          radius, 180, segments, r, g, b, a);
        drawCornerArc(x + w - radius,     y + radius,          radius, 270, segments, r, g, b, a);
        drawCornerArc(x + w - radius,     y + h - radius,      radius,   0, segments, r, g, b, a);
        drawCornerArc(x + radius,         y + h - radius,      radius,  90, segments, r, g, b, a);

        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
    }

    private static void drawCornerArc(double cx, double cy, double r,
                                      double startDeg, int segments,
                                      float red, float green, float blue, float alpha) {
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(GL11.GL_TRIANGLE_FAN, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(cx, cy, 0).color(red, green, blue, alpha).endVertex();
        for (int i = 0; i <= segments; i++) {
            double angle = Math.toRadians(startDeg + i * 90.0 / segments);
            wr.pos(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r, 0)
              .color(red, green, blue, alpha).endVertex();
        }
        tess.draw();
    }

    // ---------------------------------------------------------------  Alpha helpers

    public static void enableAlpha() {
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
    }

    public static void disableAlpha() {
        GlStateManager.disableBlend();
    }

    // ---------------------------------------------------------------  Color interpolation

    /**
     * Linearly interpolates between two packed ARGB colors.
     * @param t value in [0, 1]
     */
    public static int lerpColor(int colorA, int colorB, float t) {
        int a1 = (colorA >> 24) & 0xFF, r1 = (colorA >> 16) & 0xFF,
            g1 = (colorA >>  8) & 0xFF, b1 =  colorA        & 0xFF;
        int a2 = (colorB >> 24) & 0xFF, r2 = (colorB >> 16) & 0xFF,
            g2 = (colorB >>  8) & 0xFF, b2 =  colorB        & 0xFF;
        int a = (int)(a1 + (a2 - a1) * t), r = (int)(r1 + (r2 - r1) * t),
            g = (int)(g1 + (g2 - g1) * t), b = (int)(b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Packs separate A, R, G, B byte values into a single ARGB int. */
    public static int argb(int a, int r, int g, int b) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Returns a colour with adjusted alpha. */
    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    // ---------------------------------------------------------------  Chroma colour (time-based rainbow)

    /**
     * Returns a chroma / rainbow colour that cycles over time.
     * @param offset phase offset so multiple elements shift independently.
     */
    public static int chromaColor(long offset) {
        float hue = (float)((System.currentTimeMillis() + offset) % 5000L) / 5000f;
        return Color.HSBtoRGB(hue, 1f, 1f) | 0xFF000000;
    }
}

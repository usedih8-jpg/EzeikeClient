package com.ezeike.client.module.modules.qol;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.ModeSetting;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Weather Changer — client-side override that forces the rendered weather state.
 *
 * Modes:
 *   Clear  — forces rainStrength and thunderStrength to 0 each tick
 *   Rain   — forces rainStrength to 1
 *   Thunder — forces both rain and thunder to 1
 *
 * This is purely visual and has no effect on server-side weather.
 */
public class WeatherChanger extends Module {

    private final ModeSetting mode = register(
        new ModeSetting("Mode", "Weather to simulate.", "Clear", "Clear", "Rain", "Thunder"));

    public WeatherChanger() {
        super("Weather Changer", Category.QOL, "Client-side weather override.");
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || mc.theWorld == null) return;

        switch (mode.getValue()) {
            case "Clear":
                mc.theWorld.setRainStrength(0f);
                mc.theWorld.setThunderStrength(0f);
                break;
            case "Rain":
                mc.theWorld.setRainStrength(1f);
                mc.theWorld.setThunderStrength(0f);
                break;
            case "Thunder":
                mc.theWorld.setRainStrength(1f);
                mc.theWorld.setThunderStrength(1f);
                break;
        }
    }

    @Override
    public void onDisable() {
        // Restore normal weather by leaving it alone
        if (mc.theWorld != null) {
            mc.theWorld.setRainStrength(0f);
            mc.theWorld.setThunderStrength(0f);
        }
    }
}

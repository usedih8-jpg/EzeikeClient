package com.ezeike.client.module.setting;

public class BooleanSetting extends Setting<Boolean> {

    public BooleanSetting(String name, String description, boolean defaultValue) {
        super(name, description, defaultValue);
    }

    public BooleanSetting(String name, boolean defaultValue) {
        super(name, defaultValue);
    }

    public boolean isEnabled() { return value; }

    public void toggle() { value = !value; }

    @Override
    public String serialise() { return value.toString(); }

    @Override
    public void deserialise(String raw) {
        value = Boolean.parseBoolean(raw.trim());
    }
}

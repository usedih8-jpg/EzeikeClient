package com.ezeike.client.module.setting;

import java.util.Arrays;
import java.util.List;

/**
 * A setting whose value must be one of a fixed set of string options.
 */
public class ModeSetting extends Setting<String> {

    private final List<String> modes;

    public ModeSetting(String name, String description, String defaultMode, String... modes) {
        super(name, description, defaultMode);
        this.modes = Arrays.asList(modes);
    }

    public ModeSetting(String name, String defaultMode, String... modes) {
        this(name, "", defaultMode, modes);
    }

    public List<String> getModes() { return modes; }

    public boolean is(String mode) { return value.equalsIgnoreCase(mode); }

    /** Cycles to the next option in the list. */
    public void cycle() {
        int idx = modes.indexOf(value);
        value = modes.get((idx + 1) % modes.size());
    }

    @Override
    public void setValue(String v) {
        if (modes.contains(v)) this.value = v;
    }

    @Override
    public String serialise() { return value; }

    @Override
    public void deserialise(String raw) {
        String trimmed = raw.trim();
        if (modes.contains(trimmed)) value = trimmed;
    }
}

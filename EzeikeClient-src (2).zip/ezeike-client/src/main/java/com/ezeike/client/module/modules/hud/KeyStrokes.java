package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.module.setting.SliderSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.settings.GameSettings;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * KeyStrokes — pixel-faithful Lunar Client recreation.
 *
 * Layout (each cell 20×20 px, 2 px gap):
 *
 *       ┌────┐
 *       │ W  │               ← top row: W only
 *       └────┘
 *  ┌────┬────┬────┐
 *  │ A  │ S  │ D  │          ← middle row
 *  └────┴────┴────┘
 *  ┌──────────────┐
 *  │    SPACE     │          ← wide bottom key
 *  └──────────────┘
 *  ┌────┐    ┌────┐
 *  │LMB │    │RMB │          ← mouse row (with live CPS counts)
 *  └────┘    └────┘
 *
 * Pressed key: light/white fill + dark text (exactly like Lunar).
 * Idle key: very dark fill + mid-grey text.
 * Purple accent on the active key border adds the Ezeike signature.
 */
public class KeyStrokes extends Module {

    // ---------------------------------------------------------------  Settings
    private final BooleanSetting showMouse = register(new BooleanSetting("Mouse Buttons",  true));
    private final BooleanSetting showSpace = register(new BooleanSetting("Spacebar",       true));
    private final BooleanSetting showCPS   = register(new BooleanSetting("Show CPS",       true));
    private final SliderSetting  keySize   = register(new SliderSetting("Key Size", 20, 14, 28, 1));

    // ---------------------------------------------------------------  CPS tracking
    private final Deque<Long> lmbTimes = new ArrayDeque<>();
    private final Deque<Long> rmbTimes = new ArrayDeque<>();

    @SubscribeEvent
    public void onMouseInput(InputEvent.MouseInputEvent event) {
        if (!Mouse.getEventButtonState()) return;
        long now = System.currentTimeMillis();
        if (Mouse.getEventButton() == 0) lmbTimes.addLast(now);
        if (Mouse.getEventButton() == 1) rmbTimes.addLast(now);
    }

    public KeyStrokes() {
        super("KeyStrokes", Category.HUD, "Lunar-style WASD + mouse keystroke display.");
    }

    @Override public boolean isHudElement() { return true; }

    // ---------------------------------------------------------------  Render

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.thePlayer == null) return;

        // Prune CPS window
        long cutoff = System.currentTimeMillis() - 1000L;
        while (!lmbTimes.isEmpty() && lmbTimes.peekFirst() < cutoff) lmbTimes.pollFirst();
        while (!rmbTimes.isEmpty() && rmbTimes.peekFirst() < cutoff) rmbTimes.pollFirst();

        GameSettings ks = mc.gameSettings;
        int sz  = (int) keySize.getValue();
        int gap = 2;
        int ox  = (int) getPosX();
        int oy  = (int) getPosY();

        // ── Row 0 : W (centred above A-S-D)
        drawKey(ox + sz + gap, oy,
                "W", ks.keyBindForward.isKeyDown(), sz);

        // ── Row 1 : A  S  D
        int row1y = oy + sz + gap;
        drawKey(ox,                row1y, "A", ks.keyBindLeft.isKeyDown(),  sz);
        drawKey(ox + sz + gap,     row1y, "S", ks.keyBindBack.isKeyDown(),  sz);
        drawKey(ox + (sz + gap)*2, row1y, "D", ks.keyBindRight.isKeyDown(), sz);

        // ── Row 2 : SPACE (full width)
        if (showSpace.isEnabled()) {
            int row2y = oy + (sz + gap) * 2;
            int spaceW = sz * 3 + gap * 2;
            drawWideKey(ox, row2y, "SPACE", ks.keyBindJump.isKeyDown(), spaceW, sz);
        }

        // ── Row 3 : LMB  [gap]  RMB
        if (showMouse.isEnabled()) {
            int row3y = oy + (sz + gap) * (showSpace.isEnabled() ? 3 : 2) + (showSpace.isEnabled() ? gap : 0);
            boolean lDown = Mouse.isButtonDown(0);
            boolean rDown = Mouse.isButtonDown(1);
            String lLabel = showCPS.isEnabled() ? lmbTimes.size() + " CPS" : "LMB";
            String rLabel = showCPS.isEnabled() ? rmbTimes.size() + " CPS" : "RMB";
            drawKey(ox,                row3y, lLabel, lDown, sz);
            drawKey(ox + (sz + gap)*2, row3y, rLabel, rDown, sz);
        }
    }

    // ---------------------------------------------------------------  Key drawing

    /**
     * Single square key — the core visual unit, matching Lunar's flat style.
     *
     * Idle  : dark fill (#1A1A1A ~73% alpha) + mid-grey border + grey label
     * Active: near-white fill + thin purple border + dark label (reads on light bg)
     */
    private void drawKey(int x, int y, String label, boolean pressed, int sz) {
        int bg     = pressed ? HudTheme.KEY_ACTIVE_BG  : HudTheme.KEY_BG;
        int border = pressed ? HudTheme.ACCENT          : HudTheme.KEY_BORDER;
        int text   = pressed ? HudTheme.KEY_ACTIVE_TXT  : HudTheme.KEY_IDLE_TXT;

        RenderUtil.drawRoundedRect(x, y, sz, sz, HudTheme.RADIUS, bg);
        RenderUtil.drawOutline(x, y, sz, sz, pressed ? 1.5f : 1f, border);

        int lw = mc.fontRendererObj.getStringWidth(label);
        int lh = mc.fontRendererObj.FONT_HEIGHT;

        // Scale label down if it's too wide for the key
        if (lw > sz - 4) {
            float scale = (sz - 4f) / lw;
            net.minecraft.client.renderer.GlStateManager.pushMatrix();
            float cx = x + sz / 2f, cy = y + sz / 2f;
            net.minecraft.client.renderer.GlStateManager.translate(cx, cy, 0);
            net.minecraft.client.renderer.GlStateManager.scale(scale, scale, 1);
            mc.fontRendererObj.drawStringWithShadow(label, -lw / 2f, -lh / 2f, text);
            net.minecraft.client.renderer.GlStateManager.popMatrix();
        } else {
            mc.fontRendererObj.drawStringWithShadow(label,
                x + (sz - lw) / 2f,
                y + (sz - lh) / 2f,
                text);
        }
    }

    /** Wide key (Spacebar) — same visual rules but custom width. */
    private void drawWideKey(int x, int y, String label, boolean pressed, int w, int sz) {
        int bg     = pressed ? HudTheme.KEY_ACTIVE_BG  : HudTheme.KEY_BG;
        int border = pressed ? HudTheme.ACCENT          : HudTheme.KEY_BORDER;
        int text   = pressed ? HudTheme.KEY_ACTIVE_TXT  : HudTheme.KEY_IDLE_TXT;

        RenderUtil.drawRoundedRect(x, y, w, sz, HudTheme.RADIUS, bg);
        RenderUtil.drawOutline(x, y, w, sz, pressed ? 1.5f : 1f, border);

        int lw = mc.fontRendererObj.getStringWidth(label);
        int lh = mc.fontRendererObj.FONT_HEIGHT;
        mc.fontRendererObj.drawStringWithShadow(label,
            x + (w - lw) / 2f,
            y + (sz - lh) / 2f,
            text);
    }
}

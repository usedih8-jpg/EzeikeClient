package com.ezeike.client.module.modules.qol;

import com.ezeike.client.EzeikeClient;
import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * WAILA (What Am I Looking At) — shows the name and metadata of the block or
 * entity the player's crosshair is targeting, rendered as a tooltip near the
 * top-center of the screen.
 */
public class WAILA extends Module {

    private final BooleanSetting showMeta = register(new BooleanSetting("Show Metadata", true));
    private final BooleanSetting showPos  = register(new BooleanSetting("Show Position", false));

    public WAILA() {
        super("WAILA", Category.QOL, "Shows block/entity name when looking at it.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.theWorld == null || mc.thePlayer == null) return;

        MovingObjectPosition mop = mc.objectMouseOver;
        if (mop == null) return;

        String name = null;
        String sub  = null;

        if (mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            BlockPos bp    = mop.getBlockPos();
            IBlockState bs = mc.theWorld.getBlockState(bp);
            Block block    = bs.getBlock();
            name = block.getLocalizedName();
            if (showMeta.isEnabled()) {
                int meta = block.getMetaFromState(bs);
                if (meta != 0) sub = "Meta: " + meta;
            }
            if (showPos.isEnabled()) {
                sub = (sub != null ? sub + "  " : "") + "(" + bp.getX() + ", " + bp.getY() + ", " + bp.getZ() + ")";
            }
        } else if (mop.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY) {
            Entity entity = mop.entityHit;
            if (entity != null) {
                name = entity.getName();
                if (showMeta.isEnabled()) sub = entity.getClass().getSimpleName();
            }
        }

        if (name == null) return;

        ScaledResolution sr = new ScaledResolution(mc);
        int sw = sr.getScaledWidth();
        int fh = mc.fontRendererObj.FONT_HEIGHT;

        int mainW = mc.fontRendererObj.getStringWidth(name);
        int subW  = sub != null ? mc.fontRendererObj.getStringWidth(sub) : 0;
        int panelW = Math.max(mainW, subW) + 16;
        int panelH = sub != null ? fh * 2 + 8 : fh + 6;
        int x = (sw - panelW) / 2;
        int y = (int) getPosY();

        RenderUtil.drawRoundedRect(x, y, panelW, panelH, 4, HudTheme.BG);
        RenderUtil.drawOutline(x, y, panelW, panelH, 1f, HudTheme.EDGE);

        mc.fontRendererObj.drawStringWithShadow(name,
            x + (panelW - mainW) / 2f,
            y + 3,
            HudTheme.TEXT);

        if (sub != null) {
            mc.fontRendererObj.drawStringWithShadow(sub,
                x + (panelW - subW) / 2f,
                y + 3 + fh + 2,
                HudTheme.TEXT_DIM);
        }
    }
}

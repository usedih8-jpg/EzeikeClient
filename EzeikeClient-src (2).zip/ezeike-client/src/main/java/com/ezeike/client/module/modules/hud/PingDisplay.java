package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.module.setting.ModeSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Ping Display — Lunar-style compact card.
 * Colour-coded: green ≤80 ms, yellow ≤150 ms, red >150 ms.
 */
public class PingDisplay extends Module {

    private final BooleanSetting background = register(new BooleanSetting("Background", true));
    private final ModeSetting    mode       = register(new ModeSetting("Mode", "Compact", "Compact", "Labelled", "Number"));

    public PingDisplay() {
        super("Ping Display", Category.HUD, "Shows current server ping in ms.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;

        int ping = getPing();
        int pingColor = ping <= 80 ? HudTheme.GOOD : ping <= 150 ? HudTheme.OK : HudTheme.BAD;

        String label;
        switch (mode.getValue()) {
            case "Labelled": label = "Ping: " + ping + "ms"; break;
            case "Number":   label = ping + "ms"; break;
            default:         label = ping + " ms"; break;
        }

        int x = (int) getPosX(), y = (int) getPosY();
        int lw = mc.fontRendererObj.getStringWidth(label);
        int p  = HudTheme.PADDING;

        if (background.isEnabled()) {
            RenderUtil.drawRoundedRect(x - p, y - p, lw + p * 2 + 2, mc.fontRendererObj.FONT_HEIGHT + p * 2, HudTheme.RADIUS, HudTheme.BG);
        }

        mc.fontRendererObj.drawStringWithShadow(label, x + 1, y, pingColor);
    }

    private int getPing() {
        if (mc.getNetHandler() == null || mc.thePlayer == null) return 0;
        NetworkPlayerInfo info = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
        return info != null ? info.getResponseTime() : 0;
    }
}

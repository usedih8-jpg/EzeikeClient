package com.ezeike.client;

import com.ezeike.client.config.ConfigManager;
import com.ezeike.client.event.EventManager;
import com.ezeike.client.gui.GuiHUDConfig;
import com.ezeike.client.module.ModuleManager;
import com.ezeike.client.util.Logger;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Ezeike Client — Main entry point.
 *
 * Theme: Summer Night / Moon Chill
 *   Deep ocean navy  #0D1B2A  backgrounds
 *   Moonlight silver #C8D8E8  text / highlights
 *   Cool teal        #4ECDC4  accent (like light on night water)
 */
@Mod(
    modid     = EzeikeClient.MOD_ID,
    name      = EzeikeClient.MOD_NAME,
    version   = EzeikeClient.VERSION,
    clientSideOnly = true,
    acceptedMinecraftVersions = "[1.8.9]"
)
public class EzeikeClient {

    // ---------------------------------------------------------------  Constants
    public static final String MOD_ID   = "ezeikeclient";
    public static final String MOD_NAME = "Ezeike Client";
    public static final String VERSION  = "1.0.0";

    // ---------------------------------------------------------------  Theme palette
    /** Teal accent — primary highlight colour. */
    public static final int COLOR_ACCENT       = 0xFF4ECDC4;
    /** Lighter teal for active states. */
    public static final int COLOR_ACCENT_LIGHT = 0xFF7EECEA;
    /** Sky blue — secondary accent. */
    public static final int COLOR_SKY          = 0xFF89CFF0;
    /** Deep navy — panel / card background. */
    public static final int COLOR_BG           = 0x8C0D1B2A;
    /** Deeper navy — borders, separators. */
    public static final int COLOR_BG_DEEP      = 0xCC091422;
    /** Moonlight silver — primary text. */
    public static final int COLOR_TEXT         = 0xFFE8F0F8;
    /** Muted blue-grey — secondary text. */
    public static final int COLOR_TEXT_DIM     = 0xFF8BA3BF;

    // ---------------------------------------------------------------  Keybinds
    public static KeyBinding KEY_HUD_EDITOR;
    public static KeyBinding KEY_MODULE_GUI;

    // ---------------------------------------------------------------  Singleton
    @Mod.Instance(MOD_ID)
    private static EzeikeClient instance;
    public static EzeikeClient getInstance() { return instance; }

    // ---------------------------------------------------------------  Managers
    private ModuleManager moduleManager;
    private ConfigManager  configManager;
    private EventManager   eventManager;

    // ---------------------------------------------------------------  Forge lifecycle

    @EventHandler
    public void onPreInit(FMLPreInitializationEvent event) {
        Logger.info("Pre-init " + MOD_NAME + " v" + VERSION);
        KEY_HUD_EDITOR = new KeyBinding("Open HUD Editor",  Keyboard.KEY_RSHIFT,   MOD_NAME);
        KEY_MODULE_GUI = new KeyBinding("Open Module GUI",  Keyboard.KEY_RCONTROL, MOD_NAME);
    }

    @EventHandler
    public void onInit(FMLInitializationEvent event) {
        Logger.info("Initialising " + MOD_NAME);
        configManager = new ConfigManager();
        moduleManager = new ModuleManager();
        eventManager  = new EventManager();

        moduleManager.registerAll();
        configManager.load();

        net.minecraftforge.fml.client.registry.ClientRegistry.registerKeyBinding(KEY_HUD_EDITOR);
        net.minecraftforge.fml.client.registry.ClientRegistry.registerKeyBinding(KEY_MODULE_GUI);

        MinecraftForge.EVENT_BUS.register(this);
        Logger.info(MOD_NAME + " ready — " + moduleManager.getModules().size() + " modules.");
    }

    @EventHandler
    public void onPostInit(FMLPostInitializationEvent event) {
        Logger.info("Post-init complete.");
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (KEY_HUD_EDITOR.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new GuiHUDConfig());
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (moduleManager != null) moduleManager.onTick();
    }

    public ModuleManager getModuleManager() { return moduleManager; }
    public ConfigManager  getConfigManager()  { return configManager; }
    public EventManager   getEventManager()   { return eventManager; }
    public static Minecraft mc() { return Minecraft.getMinecraft(); }
}

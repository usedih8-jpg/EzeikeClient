package com.ezeike.client.config;

import com.ezeike.client.EzeikeClient;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.Setting;
import com.ezeike.client.util.Logger;
import net.minecraft.client.Minecraft;

import java.io.*;
import java.util.*;

/**
 * Persists module states and settings to a simple key=value flat file.
 *
 * File location: .minecraft/config/ezeikeclient/modules.cfg
 *
 * Format per module:
 *   ModuleName.enabled=true
 *   ModuleName.posX=120.0
 *   ModuleName.posY=30.0
 *   ModuleName.scale=1.0
 *   ModuleName.SettingName=value
 */
public class ConfigManager {

    private static final String CONFIG_DIR  = "config/ezeikeclient";
    private static final String CONFIG_FILE = "modules.cfg";

    private File configFile;

    public ConfigManager() {
        File baseDir = new File(Minecraft.getMinecraft().mcDataDir, CONFIG_DIR);
        if (!baseDir.exists()) baseDir.mkdirs();
        configFile = new File(baseDir, CONFIG_FILE);
    }

    // ---------------------------------------------------------------  Save

    public void save() {
        Properties props = new Properties();

        for (Module m : EzeikeClient.getInstance().getModuleManager().getModules()) {
            String prefix = m.getName();
            props.setProperty(prefix + ".enabled", String.valueOf(m.isEnabled()));
            props.setProperty(prefix + ".posX",    String.valueOf(m.getPosX()));
            props.setProperty(prefix + ".posY",    String.valueOf(m.getPosY()));
            props.setProperty(prefix + ".scale",   String.valueOf(m.getScale()));

            for (Setting<?> s : m.getSettings()) {
                props.setProperty(prefix + "." + s.getName(), s.serialise());
            }
        }

        try (FileOutputStream fos = new FileOutputStream(configFile)) {
            props.store(fos, "Ezeike Client — Module Configuration");
            Logger.info("Config saved to " + configFile.getAbsolutePath());
        } catch (IOException e) {
            Logger.error("Failed to save config", e);
        }
    }

    // ---------------------------------------------------------------  Load

    @SuppressWarnings("unchecked")
    public void load() {
        if (!configFile.exists()) {
            Logger.info("No config file found — using defaults.");
            return;
        }

        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(configFile)) {
            props.load(fis);
        } catch (IOException e) {
            Logger.error("Failed to load config", e);
            return;
        }

        for (Module m : EzeikeClient.getInstance().getModuleManager().getModules()) {
            String prefix = m.getName();

            String enabled = props.getProperty(prefix + ".enabled");
            if (enabled != null) m.setEnabled(Boolean.parseBoolean(enabled));

            String posX = props.getProperty(prefix + ".posX");
            if (posX != null) { try { m.setPosX(Double.parseDouble(posX)); } catch (NumberFormatException ignored) {} }

            String posY = props.getProperty(prefix + ".posY");
            if (posY != null) { try { m.setPosY(Double.parseDouble(posY)); } catch (NumberFormatException ignored) {} }

            String scale = props.getProperty(prefix + ".scale");
            if (scale != null) { try { m.setScale(Double.parseDouble(scale)); } catch (NumberFormatException ignored) {} }

            for (Setting<?> s : m.getSettings()) {
                String val = props.getProperty(prefix + "." + s.getName());
                if (val != null) s.deserialise(val);
            }
        }

        Logger.info("Config loaded from " + configFile.getAbsolutePath());
    }
}

package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Day Counter — Lunar-style two-line card.
 *
 *   ┌──────────────────┐
 *   │ Day  142         │
 *   │ 0:14:33          │
 *   └──────────────────┘
 */
public class DayCounter extends Module {

    private final BooleanSetting background = register(new BooleanSetting("Background", true));
    private final BooleanSetting showTime   = register(new BooleanSetting("Playtime", true));

    private final long sessionStart = System.currentTimeMillis();

    public DayCounter() {
        super("Day Counter", Category.HUD, "Shows Minecraft day and session playtime.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.theWorld == null) return;

        long day     = mc.theWorld.getWorldTime() / 24000L;
        String dayStr = "Day  " + day;

        long elapsed = (System.currentTimeMillis() - sessionStart) / 1000L;
        String timeStr = String.format("%d:%02d:%02d", elapsed / 3600, (elapsed % 3600) / 60, elapsed % 60);

        int x = (int) getPosX(), y = (int) getPosY();
        int fh = mc.fontRendererObj.FONT_HEIGHT;
        int p  = HudTheme.PADDING + 2;
        int lines = showTime.isEnabled() ? 2 : 1;
        int cardW = Math.max(mc.fontRendererObj.getStringWidth(dayStr),
                    showTime.isEnabled() ? mc.fontRendererObj.getStringWidth(timeStr) : 0) + p * 2 + 2;
        int cardH = fh * lines + p * 2 + (lines > 1 ? 2 : 0);

        if (background.isEnabled()) {
            RenderUtil.drawRoundedRect(x - p, y - p, cardW, cardH, HudTheme.RADIUS, HudTheme.BG);
        }

        mc.fontRendererObj.drawStringWithShadow(dayStr, x + 1, y, HudTheme.TEXT);
        if (showTime.isEnabled()) {
            mc.fontRendererObj.drawStringWithShadow(timeStr, x + 1, y + fh + 1, HudTheme.TEXT_DIM);
        }
    }
}

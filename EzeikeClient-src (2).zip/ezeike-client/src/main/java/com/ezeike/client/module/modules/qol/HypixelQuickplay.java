package com.ezeike.client.module.modules.qol;

import com.ezeike.client.module.Module;
import net.minecraft.client.gui.GuiChat;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

import java.util.Arrays;
import java.util.List;

/**
 * Hypixel Quickplay — opens a small menu of common game-mode macros.
 * Default keybind: H (configurable).
 *
 * Each macro fires the corresponding {@code /play <gamemode>} command.
 *
 * Full GUI is in GuiQuickplay; this module acts as the keybind handler.
 */
public class HypixelQuickplay extends Module {

    private static final int KEY = Keyboard.KEY_H;

    /** All supported Hypixel game ID strings. */
    public static final List<String[]> GAMES = Arrays.asList(
        new String[]{"Bed Wars Solos",   "bedwars_eight_one"},
        new String[]{"Bed Wars Doubles",  "bedwars_eight_two"},
        new String[]{"Bed Wars 3v3v3v3",  "bedwars_four_three"},
        new String[]{"Bed Wars 4v4v4v4",  "bedwars_four_four"},
        new String[]{"Sky Wars Solos",    "skywars_solo_normal"},
        new String[]{"Sky Wars Teams",    "skywars_team_normal"},
        new String[]{"UHC Solo",          "uhc_solo"},
        new String[]{"UHC Teams",         "uhc_teams"},
        new String[]{"Duels",             "duels_lobby"},
        new String[]{"The Bridge",        "bridge_duel"},
        new String[]{"Murder Mystery",    "murder_classic"},
        new String[]{"Build Battle",      "build_battle_solo_normal"},
        new String[]{"Arcade",            "arcade_lobby"},
        new String[]{"Housing",           "housing"}
    );

    public HypixelQuickplay() {
        super("Hypixel Quickplay", Category.QOL, "Quick-join Hypixel games via macro menu.");
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (Keyboard.isKeyDown(KEY) && mc.currentScreen == null) {
            mc.displayGuiScreen(new GuiQuickplay());
        }
    }

    /** Sends a /play command for the given game ID. */
    public static void quickplay(String gameId) {
        if (mc.thePlayer != null) {
            mc.thePlayer.sendChatMessage("/play " + gameId);
        }
    }
}

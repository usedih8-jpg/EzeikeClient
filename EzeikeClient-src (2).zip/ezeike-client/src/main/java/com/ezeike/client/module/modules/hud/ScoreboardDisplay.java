package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.*;

/**
 * Scoreboard Display — Lunar-style scoreboard renderer.
 *
 * Visual breakdown (matches Lunar exactly):
 *
 *   ┌──────────────────────────┐   ← no outer glow, very dark BG
 *   │  ◈ BedWars (Solo)        │   ← accent-coloured title, centred
 *   ├──────────────────────────┤   ← 1 px separator in EDGE colour
 *   │  PlayerName         12   │   ← white name, dim score right-aligned
 *   │  AnotherOne          9   │
 *   │  ...                     │
 *   └──────────────────────────┘
 *
 * Vanity differences from vanilla:
 *   • No red score column on the right — numbers are dim-grey.
 *   • Purple accent only on the title row.
 *   • No heavy black sidebar; card floats cleanly on the HUD.
 *
 * Cancel the vanilla scoreboard in a mixin targeting GuiIngame#renderScoreboard.
 */
public class ScoreboardDisplay extends Module {

    private final BooleanSetting showNumbers = register(new BooleanSetting("Numbers", true));
    private final BooleanSetting showTitle   = register(new BooleanSetting("Title",   true));

    private static final int MAX_ENTRIES = 15;
    private static final int ROW_H       = 11;
    private static final int PAD_X       = 6;
    private static final int PAD_Y       = 4;

    public ScoreboardDisplay() {
        super("Scoreboard", Category.HUD, "Lunar-style clean scoreboard renderer.");
    }

    @Override public boolean isHudElement() { return true; }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.theWorld == null) return;

        Scoreboard sb = mc.theWorld.getScoreboard();
        ScoreObjective obj = sb.getObjectiveInDisplaySlot(1);
        if (obj == null) return;

        // Collect + sort entries (highest score first, cap at 15)
        List<Score> scores = new ArrayList<>(sb.getSortedScores(obj));
        if (scores.size() > MAX_ENTRIES) scores = scores.subList(scores.size() - MAX_ENTRIES, scores.size());
        Collections.reverse(scores);   // now highest score is at index 0

        // Measure card width
        int fh    = mc.fontRendererObj.FONT_HEIGHT;
        String title = obj.getDisplayName();
        int maxW  = mc.fontRendererObj.getStringWidth(title);

        for (Score s : scores) {
            ScorePlayerTeam team = sb.getPlayersTeam(s.getPlayerName());
            String line = ScorePlayerTeam.formatPlayerName(team, s.getPlayerName());
            int lw = mc.fontRendererObj.getStringWidth(line);
            if (showNumbers.isEnabled()) lw += mc.fontRendererObj.getStringWidth("  " + s.getScorePoints());
            if (lw > maxW) maxW = lw;
        }

        int cardW = maxW + PAD_X * 2;
        int titleH = showTitle.isEnabled() ? ROW_H + 2 : 0;
        int cardH  = titleH + ROW_H * scores.size() + PAD_Y * 2;

        int x = (int) getPosX(), y = (int) getPosY();

        // ── Card background
        RenderUtil.drawRoundedRect(x, y, cardW, cardH, HudTheme.RADIUS, HudTheme.BG);

        // ── Title row
        if (showTitle.isEnabled()) {
            // Thin accent strip behind title
            RenderUtil.drawRoundedRect(x, y, cardW, titleH, HudTheme.RADIUS, 0x55000000);
            // 1 px separator line
            RenderUtil.drawRect(x, y + titleH, cardW, 1, HudTheme.EDGE);

            int tw = mc.fontRendererObj.getStringWidth(title);
            mc.fontRendererObj.drawStringWithShadow(title,
                x + (cardW - tw) / 2f,
                y + (titleH - fh) / 2f,
                HudTheme.ACCENT);
        }

        // ── Score rows
        for (int i = 0; i < scores.size(); i++) {
            Score s = scores.get(i);
            ScorePlayerTeam team = sb.getPlayersTeam(s.getPlayerName());
            String name = ScorePlayerTeam.formatPlayerName(team, s.getPlayerName());

            int ry = y + titleH + PAD_Y + i * ROW_H;

            // Alternate row tint (very subtle)
            if (i % 2 == 1) RenderUtil.drawRect(x + 1, ry - 1, cardW - 2, ROW_H, 0x0AFFFFFF);

            mc.fontRendererObj.drawStringWithShadow(name, x + PAD_X, ry, HudTheme.TEXT);

            if (showNumbers.isEnabled()) {
                String num = String.valueOf(s.getScorePoints());
                int nw = mc.fontRendererObj.getStringWidth(num);
                mc.fontRendererObj.drawStringWithShadow(num,
                    x + cardW - PAD_X - nw, ry, HudTheme.TEXT_DARK);
            }
        }
    }
}

package com.ezeike.client.module.modules.visual;

import com.ezeike.client.module.Module;
import net.minecraft.client.Minecraft;

/**
 * Fullbright — overrides Minecraft's gamma to maximum so the world is always
 * fully lit regardless of light level.  Toggle off restores the user's original gamma.
 */
public class Fullbright extends Module {

    private static final float GAMMA_MAX = 10.0f;
    private float originalGamma;

    public Fullbright() {
        super("Fullbright", Category.VISUAL, "Renders the world at maximum brightness.");
    }

    @Override
    public void onEnable() {
        originalGamma = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting = GAMMA_MAX;
    }

    @Override
    public void onDisable() {
        mc.gameSettings.gammaSetting = originalGamma;
    }
}

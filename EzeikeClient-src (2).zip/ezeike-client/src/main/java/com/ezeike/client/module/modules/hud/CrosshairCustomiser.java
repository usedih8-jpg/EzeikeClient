package com.ezeike.client.module.modules.hud;

import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.module.setting.ColorSetting;
import com.ezeike.client.module.setting.ModeSetting;
import com.ezeike.client.module.setting.SliderSetting;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * Crosshair Customiser — Lunar-accurate reproduction.
 *
 * Lunar's default crosshair is a simple cross:
 *   • No center gap by default.
 *   • 1 px thick, ~5 px half-length.
 *   • Pure white with no outline.
 *   • Optional dynamic gap that widens based on player speed.
 *
 * Styles available:
 *   Default  — vanilla-like cross, 1 px, white
 *   Dot      — single centre dot
 *   Circle   — thin ring
 *   Arrow    — Lunar's "arrow" style with angular tips
 *   Dynamic  — gap grows with movement speed
 */
public class CrosshairCustomiser extends Module {

    private final ModeSetting   style   = register(new ModeSetting("Style",   "Default", "Default", "Dot", "Circle", "Dynamic", "Arrow"));
    private final ColorSetting  color   = register(new ColorSetting("Color",  0xFFFFFFFF));
    private final SliderSetting size    = register(new SliderSetting("Size",   "Half-length (px).",   5, 1, 20, 1));
    private final SliderSetting gap     = register(new SliderSetting("Gap",    "Centre gap (px).",    0, 0, 10, 1));
    private final SliderSetting thick   = register(new SliderSetting("Thick",  "Line thickness (px).", 1, 1, 4,  1));
    private final BooleanSetting outline = register(new BooleanSetting("Outline", false));

    public CrosshairCustomiser() {
        super("Crosshair Customiser", Category.HUD, "Lunar-style custom crosshair.");
    }

    @Override public boolean isHudElement() { return false; }

    @SubscribeEvent
    public void onRenderPre(RenderGameOverlayEvent.Pre event) {
        if (event.type != RenderGameOverlayEvent.ElementType.CROSSHAIRS) return;
        if (mc.gameSettings.showDebugInfo || mc.gameSettings.thirdPersonView != 0) return;
        event.setCanceled(true);   // suppress vanilla

        ScaledResolution sr = new ScaledResolution(mc);
        int cx = sr.getScaledWidth()  / 2;
        int cy = sr.getScaledHeight() / 2;

        int c  = color.getValue();
        int sz = (int) size.getValue();
        int gp = (int) gap.getValue();
        int th = (int) thick.getValue();

        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_ONE_MINUS_DST_COLOR, GL11.GL_ONE_MINUS_SRC_COLOR);  // Lunar's XOR blend
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();

        switch (style.getValue()) {
            case "Dot":
                drawFilledRect(cx - th, cy - th, th * 2 + 1, th * 2 + 1, c);
                break;

            case "Circle":
                drawCircle(cx, cy, sz, th, c);
                break;

            case "Arrow":
                drawArrowCross(cx, cy, sz, gp, th, c);
                break;

            case "Dynamic": {
                float spread = 0;
                if (mc.thePlayer != null) {
                    double spd = mc.thePlayer.motionX * mc.thePlayer.motionX
                               + mc.thePlayer.motionZ * mc.thePlayer.motionZ;
                    spread = (float)(Math.sqrt(spd) * 5);
                }
                drawCross(cx, cy, sz, gp + (int) spread, th, c);
                break;
            }

            default: // Default
                drawCross(cx, cy, sz, gp, th, c);
                break;
        }

        if (outline.isEnabled()) {
            // 1 px black outline drawn slightly larger for readability
            GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            int outlineC = 0xFF000000;
            drawCross(cx, cy, sz + 1, gp, th + 2, outlineC);
            drawCross(cx, cy, sz,     gp, th,     c);
        }

        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    // ---------------------------------------------------------------  Drawing primitives

    /** Classic cross: two bars, meeting at centre with optional gap. */
    private void drawCross(int cx, int cy, int sz, int gp, int th, int c) {
        int half = th / 2;
        // Horizontal
        drawFilledRect(cx - sz, cy - half, sz - gp, th, c);          // left arm
        drawFilledRect(cx + gp + 1, cy - half, sz - gp, th, c);      // right arm
        // Vertical
        drawFilledRect(cx - half, cy - sz, th, sz - gp, c);           // top arm
        drawFilledRect(cx - half, cy + gp + 1, th, sz - gp, c);      // bottom arm
    }

    /** Arrow-style cross — arms taper to a point (simple isoceles triangle tips). */
    private void drawArrowCross(int cx, int cy, int sz, int gp, int th, int c) {
        // Base cross
        drawCross(cx, cy, sz, gp, th, c);
        // Arrow tips: a small triangle at each end
        float ac = ((c >> 24) & 0xFF) / 255f, rc = ((c >> 16) & 0xFF) / 255f,
              gc = ((c >>  8) & 0xFF) / 255f, bc = (c & 0xFF) / 255f;
        Tessellator t = Tessellator.getInstance();
        WorldRenderer w = t.getWorldRenderer();
        int half = th / 2;
        // Right tip
        w.begin(GL11.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);
        w.pos(cx + sz,      cy - half, 0).color(rc, gc, bc, ac).endVertex();
        w.pos(cx + sz,      cy + half, 0).color(rc, gc, bc, ac).endVertex();
        w.pos(cx + sz + 3,  cy,        0).color(rc, gc, bc, ac).endVertex();
        // Left tip
        w.pos(cx - sz,      cy - half, 0).color(rc, gc, bc, ac).endVertex();
        w.pos(cx - sz,      cy + half, 0).color(rc, gc, bc, ac).endVertex();
        w.pos(cx - sz - 3,  cy,        0).color(rc, gc, bc, ac).endVertex();
        // Bottom tip
        w.pos(cx - half,    cy + sz,   0).color(rc, gc, bc, ac).endVertex();
        w.pos(cx + half,    cy + sz,   0).color(rc, gc, bc, ac).endVertex();
        w.pos(cx,           cy + sz + 3,0).color(rc, gc, bc, ac).endVertex();
        // Top tip
        w.pos(cx - half,    cy - sz,   0).color(rc, gc, bc, ac).endVertex();
        w.pos(cx + half,    cy - sz,   0).color(rc, gc, bc, ac).endVertex();
        w.pos(cx,           cy - sz - 3,0).color(rc, gc, bc, ac).endVertex();
        t.draw();
    }

    private void drawFilledRect(int x, int y, int w, int h, int c) {
        float a = ((c >> 24) & 0xFF) / 255f, r = ((c >> 16) & 0xFF) / 255f,
              g = ((c >>  8) & 0xFF) / 255f, b = (c & 0xFF) / 255f;
        Tessellator ts = Tessellator.getInstance();
        WorldRenderer wr = ts.getWorldRenderer();
        wr.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x,     y,     0).color(r, g, b, a).endVertex();
        wr.pos(x,     y + h, 0).color(r, g, b, a).endVertex();
        wr.pos(x + w, y + h, 0).color(r, g, b, a).endVertex();
        wr.pos(x + w, y,     0).color(r, g, b, a).endVertex();
        ts.draw();
    }

    private void drawCircle(int cx, int cy, int radius, int th, int c) {
        float a = ((c >> 24) & 0xFF) / 255f, r = ((c >> 16) & 0xFF) / 255f,
              g = ((c >>  8) & 0xFF) / 255f, b = (c & 0xFF) / 255f;
        GL11.glLineWidth(th);
        Tessellator ts = Tessellator.getInstance();
        WorldRenderer wr = ts.getWorldRenderer();
        int seg = 64;
        wr.begin(GL11.GL_LINE_LOOP, DefaultVertexFormats.POSITION_COLOR);
        for (int i = 0; i <= seg; i++) {
            double ang = 2 * Math.PI * i / seg;
            wr.pos(cx + Math.cos(ang) * radius, cy + Math.sin(ang) * radius, 0)
              .color(r, g, b, a).endVertex();
        }
        ts.draw();
        GL11.glLineWidth(1);
    }
}

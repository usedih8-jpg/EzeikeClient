package com.ezeike.client.module.modules.qol;

import com.ezeike.client.EzeikeClient;
import com.ezeike.client.gui.HudTheme;
import com.ezeike.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

import java.io.IOException;

/**
 * Quickplay GUI — Summer Night theme.
 *
 * Deep navy card, teal header, moonlight-silver text.
 * Rows glow softly on hover with a teal tint.
 */
public class GuiQuickplay extends GuiScreen {

    private static final int PANEL_W  = 220;
    private static final int ROW_H    = 18;
    private static final int HEADER_H = 24;

    private int panelX, panelY, panelH;

    @Override
    public void initGui() {
        super.initGui();
        ScaledResolution sr = new ScaledResolution(mc);
        panelH = HEADER_H + ROW_H * HypixelQuickplay.GAMES.size() + 8;
        panelX = (sr.getScaledWidth()  - PANEL_W) / 2;
        panelY = (sr.getScaledHeight() - panelH)  / 2;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        // Panel — deep navy card with barely-visible silver edge
        RenderUtil.drawRoundedRect(panelX, panelY, PANEL_W, panelH, 6, HudTheme.BG_TITLE);
        RenderUtil.drawOutline(panelX, panelY, PANEL_W, panelH, 1.5f, HudTheme.EDGE_HOVER);

        // Header — soft teal-to-navy gradient (like moonlight fading into ocean)
        RenderUtil.drawGradientH(panelX, panelY, PANEL_W, HEADER_H,
            0xFF0E3D3A,   // deep teal-navy
            0xFF091422);  // ocean black

        // Thin teal accent line under header
        RenderUtil.drawRect(panelX, panelY + HEADER_H - 1, PANEL_W, 1, RenderUtil.withAlpha(HudTheme.ACCENT, 120));

        // Title
        String title = "Hypixel Quickplay";
        mc.fontRendererObj.drawStringWithShadow(title,
            panelX + (PANEL_W - mc.fontRendererObj.getStringWidth(title)) / 2f,
            panelY + (HEADER_H - mc.fontRendererObj.FONT_HEIGHT) / 2f,
            HudTheme.TEXT);

        // Game rows
        for (int i = 0; i < HypixelQuickplay.GAMES.size(); i++) {
            String[] game = HypixelQuickplay.GAMES.get(i);
            int rowY = panelY + HEADER_H + ROW_H * i;
            boolean hov = mouseX >= panelX && mouseX <= panelX + PANEL_W
                       && mouseY >= rowY   && mouseY <= rowY + ROW_H;

            // Hover: soft teal tint
            if (hov) RenderUtil.drawRect(panelX + 2, rowY + 1, PANEL_W - 4, ROW_H - 2, 0x224ECDC4);

            // Subtle separator between rows
            if (i > 0) RenderUtil.drawRect(panelX + 8, rowY, PANEL_W - 16, 1, HudTheme.EDGE);

            mc.fontRendererObj.drawStringWithShadow(game[0],
                panelX + 12,
                rowY + (ROW_H - mc.fontRendererObj.FONT_HEIGHT) / 2f,
                hov ? HudTheme.ACCENT : HudTheme.TEXT_DIM);
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton != 0) return;

        for (int i = 0; i < HypixelQuickplay.GAMES.size(); i++) {
            String[] game = HypixelQuickplay.GAMES.get(i);
            int rowY = panelY + HEADER_H + ROW_H * i;
            if (mouseX >= panelX && mouseX <= panelX + PANEL_W
             && mouseY >= rowY   && mouseY <= rowY + ROW_H) {
                HypixelQuickplay.quickplay(game[1]);
                mc.displayGuiScreen(null);
                return;
            }
        }
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}

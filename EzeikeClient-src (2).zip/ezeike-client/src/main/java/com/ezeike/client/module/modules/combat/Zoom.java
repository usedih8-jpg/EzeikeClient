package com.ezeike.client.module.modules.combat;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import com.ezeike.client.module.setting.SliderSetting;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

/**
 * Zoom — smooth cinematic camera zoom activated by a hold-key (default: C).
 *
 * Features:
 *   • Smooth lerp in/out instead of instant snap.
 *   • Configurable zoom multiplier (FOV divisor).
 *   • Optional sensitivity reduction while zoomed.
 */
public class Zoom extends Module {

    private static final int KEY_ZOOM = Keyboard.KEY_C;

    private final SliderSetting  zoomFov    = register(new SliderSetting("Zoom FOV", "FOV while zoomed (degrees).", 10, 1, 40, 1));
    private final SliderSetting  smoothness = register(new SliderSetting("Smoothness", "Lerp speed (higher = snappier).", 0.15, 0.01, 1.0, 0.01));
    private final BooleanSetting reduceSens = register(new BooleanSetting("Reduce Sensitivity", true));

    private float currentFov   = 70f;
    private float targetFov    = 70f;
    private float originalSens = 1f;
    private boolean wasZoomed  = false;

    public Zoom() {
        super("Zoom", Category.COMBAT, "Smooth cinematic zoom on key hold.");
    }

    @Override
    public void onTick() {
        boolean zooming = Keyboard.isKeyDown(KEY_ZOOM);
        targetFov = zooming ? (float) zoomFov.getValue() : 70f;

        // Lerp FOV
        currentFov += (targetFov - currentFov) * (float) smoothness.getValue();

        if (zooming && !wasZoomed) {
            if (reduceSens.isEnabled()) {
                originalSens = mc.gameSettings.mouseSensitivity;
                mc.gameSettings.mouseSensitivity = 0.1f;
            }
            wasZoomed = true;
        } else if (!zooming && wasZoomed) {
            if (reduceSens.isEnabled()) {
                mc.gameSettings.mouseSensitivity = originalSens;
            }
            wasZoomed = false;
        }
    }

    @Override
    public void onDisable() {
        currentFov = 70f;
        targetFov  = 70f;
        if (wasZoomed && reduceSens.isEnabled()) {
            mc.gameSettings.mouseSensitivity = originalSens;
        }
        wasZoomed = false;
    }

    @SubscribeEvent
    public void onFovUpdate(FOVUpdateEvent event) {
        // Forge passes FOV as a multiplier; normalise to degrees first
        event.newfov = (currentFov / 70f) * event.newfov;
    }
}

package com.ezeike.client.module.modules.visual;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.SliderSetting;

/**
 * Particle Changer — multiplies or suppresses the quantity of
 * damage/critical-hit particles spawned during combat.
 *
 * Values:
 *   0.0 = no particles
 *   1.0 = vanilla quantity
 *   5.0 = 5× particles
 *
 * The actual spawn-count multiplication is applied in a mixin targeting
 * {@code World#spawnParticle}.  This class exposes the multiplier.
 */
public class ParticleChanger extends Module {

    private static ParticleChanger INSTANCE;

    private final SliderSetting multiplier = register(
        new SliderSetting("Multiplier", "Particle quantity multiplier.", 1.0, 0.0, 10.0, 0.5));

    public ParticleChanger() {
        super("Particle Changer", Category.VISUAL, "Adjusts combat particle density.");
        INSTANCE = this;
    }

    public static float getMultiplier() {
        return INSTANCE != null && INSTANCE.isEnabled()
            ? INSTANCE.multiplier.getValue().floatValue()
            : 1f;
    }
}

package com.ezeike.client.module.modules.qol;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.BooleanSetting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * FreeLook (360° Camera) — decouples camera rotation from player body rotation
 * while the hold key is pressed.
 *
 * Implementation:
 *   • On each render tick, capture the mouse delta.
 *   • Apply delta to a separate camera yaw/pitch instead of the player's.
 *   • Inject camera angles via {@code Entity.renderYawOffset} override in a mixin
 *     or by adjusting Minecraft's camera via EntityRenderer.
 *
 * Note: The actual render injection requires a mixin targeting
 * {@code Entity#applyEntityCollision} or the camera rotation methods.
 * This class handles the keybind and state management.
 */
public class FreeLook extends Module {

    private static final int KEY = Keyboard.KEY_V;

    private final BooleanSetting invertY = register(new BooleanSetting("Invert Y", false));

    private boolean active = false;

    /** Camera yaw offset from the player's actual yaw. */
    public float cameraYaw   = 0f;
    /** Camera pitch offset. */
    public float cameraPitch = 0f;

    private float savedPlayerYaw, savedPlayerPitch;

    public FreeLook() {
        super("FreeLook", Category.QOL, "Hold key to rotate camera independently of player.");
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || mc.thePlayer == null) return;

        boolean holding = Keyboard.isKeyDown(KEY);

        if (holding && !active) {
            active           = true;
            savedPlayerYaw   = mc.thePlayer.rotationYaw;
            savedPlayerPitch = mc.thePlayer.rotationPitch;
            cameraYaw        = 0f;
            cameraPitch      = 0f;
        } else if (!holding && active) {
            active = false;
            // Restore player rotation from saved values
            mc.thePlayer.rotationYaw   = savedPlayerYaw;
            mc.thePlayer.rotationPitch = savedPlayerPitch;
        }
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        // Additional key handling if needed
    }

    public boolean isActive()       { return active; }
    public boolean isInvertY()      { return invertY.isEnabled(); }

    @Override
    public void onDisable() {
        active = false;
        if (mc.thePlayer != null) {
            mc.thePlayer.rotationYaw   = savedPlayerYaw;
            mc.thePlayer.rotationPitch = savedPlayerPitch;
        }
    }
}

package com.ezeike.client.launch;

import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

import java.util.Map;

/**
 * FML Core Plugin entry point.
 *
 * Required so Forge can find the class declared in the JAR manifest's
 * "FMLCorePlugin" attribute. No actual transformation is done here —
 * the Essential tweaker handles loading; this class just satisfies Forge.
 */
@IFMLLoadingPlugin.MCVersion("1.8.9")
@IFMLLoadingPlugin.Name("EzeikeClient")
@IFMLLoadingPlugin.SortingIndex(1001)
public class EzeikeLaunchWrapper implements IFMLLoadingPlugin {

    @Override
    public String[] getASMTransformerClass() {
        return new String[0];
    }

    @Override
    public String getModContainerClass() {
        return null;
    }

    @Override
    public String getSetupClass() {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> data) {
        // Nothing to inject
    }

    @Override
    public String getAccessTransformerClass() {
        return null;
    }
}

package com.ezeike.client.module.setting;

/**
 * Generic setting that a {@link com.ezeike.client.module.Module} can expose.
 *
 * Concrete subclasses:
 *   BooleanSetting  — on/off toggle
 *   SliderSetting   — numeric range
 *   ColorSetting    — ARGB integer
 *   ModeSetting     — enum / string list
 */
public abstract class Setting<T> {

    private final String name;
    private final String description;
    protected T value;

    public Setting(String name, String description, T defaultValue) {
        this.name        = name;
        this.description = description;
        this.value       = defaultValue;
    }

    public Setting(String name, T defaultValue) {
        this(name, "", defaultValue);
    }

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public T      getValue()       { return value; }

    public void setValue(T value)  { this.value = value; }

    /** Serialise to a string for the config file. */
    public abstract String serialise();

    /** Deserialise from a config string. */
    public abstract void deserialise(String raw);
}

package com.ezeike.client.module;

import com.ezeike.client.module.modules.combat.*;
import com.ezeike.client.module.modules.hud.*;
import com.ezeike.client.module.modules.visual.*;
import com.ezeike.client.module.modules.qol.*;
import com.ezeike.client.util.Logger;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Central registry for all {@link Module} instances.
 *
 * Usage pattern:
 *   EzeikeClient.getInstance().getModuleManager().getByName("Fullbright")
 */
public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    // ---------------------------------------------------------------  Registration

    /**
     * Instantiate and register every module.
     * Grouped by category for readability.
     */
    public void registerAll() {

        // Visual / Performance
        register(new Fullbright());
        register(new FOVChanger());
        register(new GlintColorizer());
        register(new ChunkBorders());
        register(new HitColor());
        register(new MotionBlur());
        register(new ParticleChanger());

        // HUD
        register(new FPSDisplay());
        register(new PingDisplay());
        register(new CPSDisplay());
        register(new KeyStrokes());
        register(new ArmorStatus());
        register(new PotionEffects());
        register(new CrosshairCustomiser());
        register(new ScoreboardDisplay());
        register(new ServerAddress());
        register(new Coordinates());
        register(new DayCounter());

        // Combat
        register(new Zoom());
        register(new TNTCountdown());
        register(new NameTags());
        register(new DamageTint());

        // QoL
        register(new HypixelQuickplay());
        register(new WAILA());
        register(new WeatherChanger());
        register(new FreeLook());

        Logger.info("Registered " + modules.size() + " modules.");
    }

    private void register(Module m) {
        modules.add(m);
        m.onLoad();
    }

    // ---------------------------------------------------------------  Lookup helpers

    public List<Module> getModules() { return Collections.unmodifiableList(modules); }

    public Optional<Module> getByName(String name) {
        return modules.stream()
            .filter(m -> m.getName().equalsIgnoreCase(name))
            .findFirst();
    }

    public List<Module> getByCategory(Module.Category category) {
        return modules.stream()
            .filter(m -> m.getCategory() == category)
            .collect(Collectors.toList());
    }

    /** Returns only modules that render a HUD overlay element. */
    public List<Module> getHudModules() {
        return modules.stream()
            .filter(Module::isHudElement)
            .collect(Collectors.toList());
    }

    // ---------------------------------------------------------------  Tick delegation

    /** Called every client tick; delegates to each enabled module. */
    public void onTick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }
}

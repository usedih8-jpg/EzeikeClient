package com.ezeike.client.module.modules.visual;

import com.ezeike.client.module.Module;
import com.ezeike.client.module.setting.ColorSetting;
import com.ezeike.client.module.setting.SliderSetting;

/**
 * Hit Color — changes the flash colour displayed on entities when they take
 * damage (the red hurt flash) and adjusts the camera shake multiplier.
 *
 * The actual colour injection is performed in a mixin targeting
 * {@code Entity#setEntityState} / {@code RenderLivingBase#renderModel}.
 * This class stores the configuration that the mixin reads via static accessors.
 */
public class HitColor extends Module {

    private static HitColor INSTANCE;

    private final ColorSetting hurtColor = register(
        new ColorSetting("Hurt Color", "Flash colour when an entity takes damage.", 0xFFFF00FF));
    private final SliderSetting shakeMultiplier = register(
        new SliderSetting("Camera Shake", "Multiplier for the hurt camera shake (0 = none).", 1.0, 0.0, 3.0, 0.1));

    public HitColor() {
        super("Hit Color", Category.VISUAL, "Customises entity damage flash colour and camera shake.");
        INSTANCE = this;
    }

    public static int getHurtColor() {
        return INSTANCE != null && INSTANCE.isEnabled() ? INSTANCE.hurtColor.getValue() : 0xFFFF0000;
    }

    public static float getShakeMultiplier() {
        return INSTANCE != null && INSTANCE.isEnabled() ? INSTANCE.shakeMultiplier.getValue().floatValue() : 1f;
    }
}
